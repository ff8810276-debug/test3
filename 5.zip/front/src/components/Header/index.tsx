"use client";
import { signOut, useSession } from "next-auth/react";
import { useTheme } from "next-themes";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Cookies from "js-cookie";
import { useDispatch, useSelector } from "react-redux";
import menuData from "./menuData";

const Header = () => {
  // ---------- تمام هوک‌ها باید اول تعریف شوند ----------
  const { data: session } = useSession();
  const router = useRouter();
  const pathUrl = usePathname();
  const { theme, setTheme } = useTheme();

  const count = useSelector((state: any) => state.counter.value);
  const dispatch = useDispatch();

  const [mounted, setMounted] = useState(false);
  const [navbarOpen, setNavbarOpen] = useState(false);
  const [sticky, setSticky] = useState(false);
  const [openIndex, setOpenIndex] = useState(-1);

  const token = Cookies.get("accessToken");

  // ---------- Effects ----------
  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const handleStickyNavbar = () => {
      setSticky(window.scrollY >= 80);
    };

    window.addEventListener("scroll", handleStickyNavbar);
    return () => window.removeEventListener("scroll", handleStickyNavbar);
  }, []);

  // ---------- Return Block After Hooks ----------
  if (!mounted) return null;

  const navbarToggleHandler = () => setNavbarOpen(!navbarOpen);

  const handleSubmenu = (index: number) =>
    setOpenIndex(openIndex === index ? -1 : index);

  const LogOut = () => {
    Cookies.remove("accessToken");
  };

  // ---------- JSX ----------
  return (
    <>
      <header
        className={`ud-header left-0 top-0 z-40 flex w-full items-center ${
          sticky
            ? "shadow-nav fixed z-[999] border-b border-stroke bg-white/80 backdrop-blur-[5px] dark:border-dark-3/20 dark:bg-dark/10"
            : "absolute bg-transparent"
        }`}
      >
        <div className="container">
          <div className="relative -mx-4 flex items-center justify-between">

            {/* LOGO */}
            <div className="w-60 max-w-full px-4">
              <Link
                href="/"
                className={`mr-[60px] navbar-logo block w-full ${
                  sticky ? "py-2" : "py-5"
                }`}
              ></Link>
            </div>

            {/* MAIN */}
            <div className="flex w-full items-center justify-between px-4">
              
              {/* MENU TOGGLER */}
              <div>
                <button
                  onClick={navbarToggleHandler}
                  className="absolute right-4 top-1/2 -translate-y-1/2 lg:hidden px-3 py-[6px]"
                >
                  <span
                    className={`block h-0.5 w-[30px] my-1.5 transition-all ${
                      navbarOpen ? "rotate-45 top-[7px]" : ""
                    } ${sticky ? "bg-dark" : "bg-white"}`}
                  />
                  <span
                    className={`block h-0.5 w-[30px] my-1.5 transition-all ${
                      navbarOpen ? "opacity-0" : ""
                    } ${sticky ? "bg-dark" : "bg-white"}`}
                  />
                  <span
                    className={`block h-0.5 w-[30px] my-1.5 transition-all ${
                      navbarOpen ? "-rotate-45 top-[-8px]" : ""
                    } ${sticky ? "bg-dark" : "bg-white"}`}
                  />
                </button>

                {/* NAVIGATION */}
                <nav
                  className={`navbar absolute right-0 z-30 w-[250px] rounded bg-white dark:bg-dark-2 p-4 transition-all 
                    ${navbarOpen ? "top-full opacity-100" : "top-[120%] opacity-0 invisible"}
                    lg:static lg:w-auto lg:visible lg:opacity-100 lg:bg-transparent lg:p-0`}
                >
                  <ul className="block lg:flex lg:gap-x-8">
                    {menuData.map((menuItem, index) =>
                      menuItem.path ? (
                        <li key={index} className="group relative">
                          <Link
                            onClick={navbarToggleHandler}
                            href={menuItem.path}
                            scroll={false}
                            className={`py-2 block lg:py-6 ${
                              pathUrl === menuItem.path
                                ? "text-primary"
                                : sticky
                                ? "text-dark dark:text-white"
                                : "text-white"
                            }`}
                          >
                            {menuItem.title}
                          </Link>
                        </li>
                      ) : (
                        <li key={index} className="submenu-item relative">
                          <button
                            onClick={() => handleSubmenu(index)}
                            className={`py-2 flex items-center justify-between lg:py-6 ${
                              sticky ? "text-dark" : "text-white"
                            }`}
                          >
                            {menuItem.title}
                          </button>

                          <div
                            className={`absolute w-[250px] bg-white dark:bg-dark-2 shadow-lg p-4 rounded top-full left-0 ${
                              openIndex === index ? "block" : "hidden"
                            }`}
                          >
                            {menuItem.submenu.map((sub, i) => (
                              <Link
                                key={i}
                                href={sub.path}
                                className="block px-4 py-2 text-sm hover:text-primary"
                              >
                                {sub.title}
                              </Link>
                            ))}
                          </div>
                        </li>
                      )
                    )}
                  </ul>
                </nav>
              </div>

              {/* RIGHT BUTTONS */}
              <div className="hidden sm:flex items-center gap-4">
                
                {/* THEME TOGGLE */}
                <button
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="text-dark dark:text-white"
                >
                  🌓
                </button>

                {/* AUTH */}
                {token ? (
                  <>
                    <p
                      className={`px-5 py-3 ${
                        sticky ? "text-dark" : "text-white"
                      }`}
                    >
                      {session?.user?.name}
                    </p>

                    <button
                      onClick={() => router.push("/Profile")}
                      className="px-6 py-3 bg-primary text-white rounded"
                    >
                      پروفایل
                    </button>

                    <button
                      onClick={() => {
                        signOut();
                        LogOut();
                      }}
                      className="px-6 py-3 bg-primary text-white rounded"
                    >
                      خروج
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      href="/signin"
                      className={`px-7 py-3 ${
                        sticky ? "text-dark" : "text-white"
                      }`}
                    >
                      ورود
                    </Link>

                    <Link
                      href="/signup"
                      className="px-6 py-3 bg-primary text-white rounded"
                    >
                      ثبت نام
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
