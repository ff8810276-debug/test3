"use client";

import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "next-themes";
import { PropsWithChildren } from "react";
import { Toaster } from "react-hot-toast";
import { Provider as ReduxProvider } from "react-redux";
import { store } from "@/store/store"; // مسیر store خودت

export default function Providers({ children }: PropsWithChildren) {
  return (
    <SessionProvider>
      <ReduxProvider store={store}>
        <ThemeProvider
          attribute="class"
          enableSystem={false}
          defaultTheme="light"
        >
          <Toaster />
          {children}
        </ThemeProvider>
      </ReduxProvider>
    </SessionProvider>
  );
}
