"use client";

import { useState } from "react";
import SectionTitle from "@/components/Common/SectionTitle";

// --- Types ---
interface TeamMember {
  id: number;
  name: string;
  designation: string;
  image: string;
  facebookLink: string;
  twitterLink: string;
  instagramLink: string;
}

interface Video {
  id: number;
  title: string;
  thumbnail: string;
  embedUrl: string;
  views: number;
  duration: string;
  uploadDate: string;
}

interface Post {
  id: number;
  title: string;
  content: string;
  image: string;
  likes: number;
  date: string;
}

interface SavedItem {
  id: number;
  title: string;
  type: "video" | "post" | "course";
  thumbnail: string;
  savedDate: string;
}

interface Course {
  id: number;
  title: string;
  progress: number;
  totalLessons: number;
  thumbnail: string;
  instructor: string;
}

// --- Fake Data ---
const profileData: TeamMember = {
  id: 1,
  name: "دکتر امیرحسین رضایی",
  designation: "مؤسس و مدیرعامل",
  image: "https://tse3.mm.bing.net/th/id/OIP.EwG6x9w6RngqsKrPJYxULAHaHa?cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3",
  facebookLink: "https://facebook.com/amirhossein.rezaei",
  twitterLink: "https://twitter.com/amirhossein_r",
  instagramLink: "https://instagram.com/amirhossein.rezaei",
};

// 1. ویدیوهای دیده‌شده
const watchedVideos: Video[] = [
  {
    id: 1,
    title: "آموزش هوش مصنوعی برای مبتدیان",
    thumbnail: "/images/videos/ai-intro.jpg",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    views: 15234,
    duration: "10:30",
    uploadDate: "2025-10-20",
  },
  {
    id: 2,
    title: "طراحی UX در اپلیکیشن‌های آموزشی",
    thumbnail: "/images/videos/ux-design.jpg",
    embedUrl: "https://www.youtube.com/embed/another-video-id",
    views: 8745,
    duration: "8:15",
    uploadDate: "2025-09-15",
  },
];

// 2. پست‌های پسندیده
const likedPosts: Post[] = [
  {
    id: 1,
    title: "یادگیری ماشین چیست؟",
    content: "در این پست به بررسی الگوریتم‌های یادگیری ماشین می‌پردازیم...",
    image: "/images/posts/ml-post.jpg",
    likes: 120,
    date: "2025-10-15",
  },
  {
    id: 2,
    title: "نکات روانشناسی یادگیری",
    content: "چگونه مغز ما اطلاعات جدید را پردازش می‌کند؟",
    image: "/images/posts/psychology-post.jpg",
    likes: 89,
    date: "2025-11-01",
  },
];

// 3. سیو شده‌ها
const savedItems: SavedItem[] = [
  {
    id: 1,
    title: "دوره کامل React + Next.js",
    type: "course",
    thumbnail: "/images/saved/react-course.jpg",
    savedDate: "2025-11-05",
  },
  {
    id: 2,
    title: "پست: ۱۰ تکنیک یادگیری سریع",
    type: "post",
    thumbnail: "/images/saved/learning-tips.jpg",
    savedDate: "2025-11-03",
  },
  {
    id: 3,
    title: "ویدیو: Tailwind CSS از صفر",
    type: "video",
    thumbnail: "/images/saved/tailwind.jpg",
    savedDate: "2025-10-30",
  },
];

// 4. ویدیوهای آپلود شده
const uploadedVideos: Video[] = [
  {
    id: 101,
    title: "معرفی LXP: آینده آموزش آنلاین",
    thumbnail: "/images/uploaded/lxp-intro.jpg",
    embedUrl: "https://www.youtube.com/embed/lxp-intro",
    views: 45210,
    duration: "15:20",
    uploadDate: "2025-07-10",
  },
  {
    id: 102,
    title: "چگونه دوره آموزشی بسازیم؟",
    thumbnail: "/images/uploaded/course-creation.jpg",
    embedUrl: "https://www.youtube.com/embed/course-create",
    views: 29800,
    duration: "22:10",
    uploadDate: "2025-06-05",
  },
];

// 5. دوره‌های در حال مطالعه
const activeCourses: Course[] = [
  {
    id: 1,
    title: "هوش مصنوعی کاربردی",
    progress: 68,
    totalLessons: 24,
    thumbnail: "/images/courses/ai-course.jpg",
    instructor: "دکتر رضایی",
  },
  {
    id: 2,
    title: "طراحی تجربه کاربری پیشرفته",
    progress: 42,
    totalLessons: 18,
    thumbnail: "/images/courses/ux-advanced.jpg",
    instructor: "سارا کریمی",
  },
];

// --- کامپوننت‌های کوچک ---
const SingleVideo = ({ video }: { video: Video }) => (
  <div className="w-full px-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
    <div className="group mb-8 rounded-lg bg-white shadow-lg transition-all hover:shadow-xl dark:bg-dark">
      <div className="relative overflow-hidden rounded-t-lg">
        <img src={video.thumbnail} alt={video.title} className="h-48 w-full object-cover transition-transform group-hover:scale-105" />
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 transition-opacity group-hover:bg-opacity-30">
          <button className="opacity-0 transition-opacity group-hover:opacity-100">
            <svg className="h-12 w-12 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        </div>
        <span className="absolute bottom-2 right-2 rounded bg-black bg-opacity-70 px-2 py-1 text-xs text-white">
          {video.duration}
        </span>
      </div>
      <div className="p-4">
        <h3 className="mb-2 line-clamp-2 text-lg font-semibold text-dark dark:text-white">{video.title}</h3>
        <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
          <span>{video.views.toLocaleString()} بازدید</span>
          <span>{video.uploadDate}</span>
        </div>
      </div>
    </div>
  </div>
);

const SinglePost = ({ post }: { post: Post }) => (
  <div className="w-full px-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
    <div className="group mb-8 rounded-lg bg-white shadow-lg transition-all hover:shadow-xl dark:bg-dark">
      {post.image && (
        <img src={post.image} alt={post.title} className="h-40 w-full rounded-t-lg object-cover transition-transform group-hover:scale-105" />
      )}
      <div className="p-4">
        <h3 className="mb-2 line-clamp-2 text-lg font-semibold text-dark dark:text-white">{post.title}</h3>
        <p className="mb-3 line-clamp-3 text-sm text-gray-600 dark:text-gray-400">{post.content}</p>
        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
          <span className="flex items-center">
            <svg className="mr-1 h-4 w-4 text-red-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
            </svg>
            {post.likes}
          </span>
          <span>{post.date}</span>
        </div>
      </div>
    </div>
  </div>
);

const SingleSaved = ({ item }: { item: SavedItem }) => (
  <div className="w-full px-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
    <div className="group mb-8 rounded-lg bg-white shadow-lg transition-all hover:shadow-xl dark:bg-dark">
      <div className="relative overflow-hidden rounded-t-lg">
        <img src={item.thumbnail} alt={item.title} className="h-48 w-full object-cover transition-transform group-hover:scale-105" />
        <div className="absolute top-2 left-2 rounded bg-blue-600 px-2 py-1 text-xs text-white">
          {item.type === "video" ? "ویدیو" : item.type === "post" ? "پست" : "دوره"}
        </div>
      </div>
      <div className="p-4">
        <h3 className="mb-2 line-clamp-2 text-lg font-semibold text-dark dark:text-white">{item.title}</h3>
        <p className="text-xs text-gray-500">ذخیره شده در {item.savedDate}</p>
      </div>
    </div>
  </div>
);

const SingleCourse = ({ course }: { course: Course }) => (
  <div className="w-full px-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
    <div className="group mb-8 rounded-lg bg-white shadow-lg transition-all hover:shadow-xl dark:bg-dark">
      <div className="relative overflow-hidden rounded-t-lg">
        <img src={course.thumbnail} alt={course.title} className="h-48 w-full object-cover transition-transform group-hover:scale-105" />
        <div className="absolute inset-x-0 bottom-0 h-2 bg-gray-300">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all"
            style={{ width: `${course.progress}%` }}
          />
        </div>
      </div>
      <div className="p-4">
        <h3 className="mb-2 line-clamp-2 text-lg font-semibold text-dark dark:text-white">{course.title}</h3>
        <p className="mb-1 text-sm text-gray-600 dark:text-gray-400">مدرس: {course.instructor}</p>
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium text-blue-600">{course.progress}% تکمیل</span>
          <span className="text-gray-500">{course.totalLessons} درس</span>
        </div>
      </div>
    </div>
  </div>
);

// --- آیکون‌های تب ---
const TabIcon = ({ type }: { type: string }) => {
  switch (type) {
    case "watched":
      return (
        <svg className="mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        </svg>
      );
    case "liked":
      return (
        <svg className="mr-2 h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
          <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
        </svg>
      );
    case "saved":
      return (
        <svg className="mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
        </svg>
      );
    case "uploaded":
      return (
        <svg className="mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
      );
    case "courses":
      return (
        <svg className="mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5s3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18s-3.332.477-4.5 1.253" />
        </svg>
      );
    default:
      return null;
  }
};

// --- کامپوننت اصلی ---
const Profile = () => {
  const [activeTab, setActiveTab] = useState<"watched" | "liked" | "saved" | "uploaded" | "courses">("watched");

  const tabs = [
    { id: "watched", label: "دیده‌شده‌ها", count: watchedVideos.length },
    { id: "liked", label: "پسندیده‌ها", count: likedPosts.length },
    { id: "saved", label: "سیو شده‌ها", count: savedItems.length },
    { id: "uploaded", label: "آپلود شده", count: uploadedVideos.length },
    { id: "courses", label: "دوره‌ها", count: activeCourses.length },
  ];

  return (
    <section id="profile" className="overflow-hidden bg-gray-1 pb-12 pt-20 dark:bg-dark-2 lg:pb-[90px] lg:pt-[120px]">
      <div className="container">
        {/* هدر پروفایل */}
        <div className="mb-[60px] text-center">
          <div className="mb-6">
            <img
              src={profileData.image}
              alt={profileData.name}
              className="mx-auto h-32 w-32 rounded-full object-cover shadow-xl ring-4 ring-white dark:ring-dark"
            />
          </div>
          <SectionTitle
            subtitle={`${profileData.designation} - پروفایل LXP`}
            title={profileData.name}
            paragraph="خوش آمدید به پروفایل من. ویدیوها، پست‌ها، دوره‌ها و محتوای ذخیره‌شده‌ام را ببینید."
            width="640px"
            center
          />
          <div className="mt-6 flex justify-center space-x-6 space-x-reverse">
            {profileData.facebookLink !== "/#" && (
              <a href={profileData.facebookLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">
                <i className="fab fa-facebook text-2xl"></i>
              </a>
            )}
            {profileData.twitterLink !== "/#" && (
              <a href={profileData.twitterLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-600">
                <i className="fab fa-twitter text-2xl"></i>
              </a>
            )}
            {profileData.instagramLink !== "/#" && (
              <a href={profileData.instagramLink} target="_blank" rel="noopener noreferrer" className="text-pink-500 hover:text-pink-700">
                <i className="fab fa-instagram text-2xl"></i>
              </a>
            )}
          </div>
        </div>

        {/* تب‌ها */}
        <div className="mb-10 flex justify-center overflow-x-auto">
          <div className="inline-flex rounded-lg border border-gray-300 bg-white p-1 dark:border-gray-700 dark:bg-dark">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center rounded-md px-4 py-2 text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white shadow-sm"
                    : "text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                }`}
              >
                <TabIcon type={tab.id} />
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>
        </div>

        {/* محتوا */}
        <div className="-mx-4 flex flex-wrap justify-center">
          {activeTab === "watched" &&
            watchedVideos.map((video) => <SingleVideo key={video.id} video={video} />)}
          {activeTab === "liked" &&
            likedPosts.map((post) => <SinglePost key={post.id} post={post} />)}
          {activeTab === "saved" &&
            savedItems.map((item) => <SingleSaved key={item.id} item={item} />)}
          {activeTab === "uploaded" &&
            uploadedVideos.map((video) => <SingleVideo key={video.id} video={video} />)}
          {activeTab === "courses" &&
            activeCourses.map((course) => <SingleCourse key={course.id} course={course} />)}
        </div>
      </div>
    </section>
  );
};

export default Profile;