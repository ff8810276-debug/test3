import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Video } from './entities/video.entity';
import { CreateVideoDto } from './dto/create-video.dto';

@Injectable()
export class VideosService {
  constructor(
    @InjectRepository(Video)
    private readonly videoRepo: Repository<Video>,
  ) {}

  findAll(): Promise<Video[]> {
    return this.videoRepo.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: number): Promise<Video> {
    const video = await this.videoRepo.findOne({ where: { id } });
    if (!video) throw new NotFoundException('Video not found');

    // افزایش بازدید مثل یوتیوب
    video.viewCount += 1;
    await this.videoRepo.save(video);

    return video;
  }

  create(dto: CreateVideoDto): Promise<Video> {
    const video = this.videoRepo.create(dto);
    return this.videoRepo.save(video);
  }

  async update(id: number, dto: Partial<CreateVideoDto>): Promise<Video> {
    const video = await this.findOne(id);
    Object.assign(video, dto);
    return this.videoRepo.save(video);
  }

  async remove(id: number): Promise<void> {
    const video = await this.findOne(id);
    await this.videoRepo.remove(video);
  }
}
