import { ApiProperty } from '@nestjs/swagger';

export class UploadMediaDto {
  @ApiProperty()
  title: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty({
    required: false,
    description: 'تگ‌ها به صورت رشته کاما جدا، مثلا: react,javascript,course',
    example: 'react,javascript,course',
  })
  tags?: string;

  @ApiProperty({
    required: false,
    description: 'مدت ویدیو به فرمت ISO8601 مثلا PT4H43M2S',
    example: 'PT4H43M2S',
  })
  duration?: string;

  @ApiProperty({
    type: 'string',
    format: 'binary',
    required: false,
    description: 'فایل ویدیویی (mp4/webm/ogg)',
  })
  video?: any;

  @ApiProperty({
    type: 'string',
    format: 'binary',
    required: false,
    description: 'تصویر کاور (jpg/png/jpeg/gif)',
  })
  image?: any;
}
