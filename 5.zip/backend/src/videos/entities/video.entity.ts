import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

@Entity('videos')
export class Video {
  @ApiProperty()
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty()
  @Column()
  title: string;

  @ApiProperty({ required: false, nullable: true })
  @Column({ nullable: true })
  description?: string;

  @ApiProperty({ required: false, nullable: true })
  @Column({ type: 'text', nullable: true })
  videoUrl: string | null;

  @ApiProperty({ required: false, nullable: true })
  @Column({ type: 'text', nullable: true })
  imageUrl: string | null;

  @ApiProperty({
    type: [String],
    required: false,
    description: 'لیست تگ‌ها مثلا ["react","javascript"]',
  })
  @Column({ type: 'simple-array', nullable: true })
  tags?: string[];

  @ApiProperty({
    required: false,
    description: 'مدت ویدیو به فرمت ISO8601 مثلا PT4H43M2S',
  })
  @Column({ nullable: true })
  duration?: string;

  @ApiProperty({ default: 0 })
  @Column({ default: 0 })
  viewCount: number;

  @ApiProperty({ default: 0 })
  @Column({ default: 0 })
  likeCount: number;

  @ApiProperty({ default: 0 })
  @Column({ default: 0 })
  commentCount: number;

  @ApiProperty()
  @CreateDateColumn()
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn()
  updatedAt: Date;
}
