import { ApiProperty } from '@nestjs/swagger';

export class CreateUserActivityDto {
  @ApiProperty({ example: 1, description: 'User ID' })
  userId: number;

  @ApiProperty({ example: 'LOGIN' })
  action: string;

  @ApiProperty({ required: false, example: 'User logged in successfully' })
  description?: string;
}
