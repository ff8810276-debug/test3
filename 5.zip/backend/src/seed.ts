import { DataSource } from 'typeorm';
import { User } from './users/user.entity';
import { Organization } from './organizations/organization.entity';
import * as bcrypt from 'bcrypt';

// ⚡ تنظیم اتصال دیتابیس مثل app.module.ts
const AppDataSource = new DataSource({
  type: 'postgres',
  host: 'shortline.proxy.rlwy.net',
  port: 12723,
  username: 'postgres',
  password: 'HfKBRFSbwDDCtoFkjrVDpeMpdXZUnHTm',
  database: 'test',
  entities: [User, Organization],
  synchronize: true, // فقط برای dev
  logging: true,
});

async function seed() {
  await AppDataSource.initialize();
  console.log('💾 Database connected');

  const orgRepo = AppDataSource.getRepository(Organization);
  const userRepo = AppDataSource.getRepository(User);

  // ✅ ایجاد سازمان‌ها
  const org1 = orgRepo.create({ name: 'TechCorp', email: 'contact@techcorp.com', phone: '+1-202-555-0188', address: '123 Tech Street, NY' });
  const org2 = orgRepo.create({ name: 'BizSolutions', email: 'info@bizsolutions.com', phone: '+1-202-555-0199', address: '456 Biz Avenue, CA' });

  await orgRepo.save([org1, org2]);

  // ✅ ایجاد کاربران
const users: Partial<User>[] = [
  {
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    password: await bcrypt.hash('123456', 10),
    organization: org1,
    role: 'ADMIN' as 'ADMIN', // ✅ cast کردن type
  },
  {
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane@example.com',
    password: await bcrypt.hash('123456', 10),
    organization: org2,
    role: 'MANAGER' as 'MANAGER', // ✅ cast کردن type
  },
];


  const userEntities = userRepo.create(users);
  await userRepo.save(userEntities);

  console.log('✅ Seed completed');
  await AppDataSource.destroy();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
