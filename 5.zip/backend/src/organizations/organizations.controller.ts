import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { OrganizationsService } from './organizations.service';
import { Organization } from './organization.entity';
import { ApiTags, ApiResponse, ApiBody } from '@nestjs/swagger';
import { CreateOrganizationDto } from './dto/create-organization.dto';
import { UpdateOrganizationDto } from './dto/update-organization.dto';

@ApiTags('Organizations')
@Controller('organizations')
export class OrganizationsController {
  constructor(private readonly organizationsService: OrganizationsService) {}

  @Get()
  @ApiResponse({ status: 200, description: 'List of organizations', type: Organization, isArray: true })
  findAll(): Promise<Organization[]> {
    return this.organizationsService.findAll();
  }

  @Get(':id')
  @ApiResponse({ status: 200, description: 'Organization details', type: Organization })
  findOne(@Param('id') id: number): Promise<Organization> {
    return this.organizationsService.findOne(id);
  }

  @Post()
  @ApiBody({ type: CreateOrganizationDto })
  @ApiResponse({ status: 201, description: 'Organization created', type: Organization })
  create(@Body() data: CreateOrganizationDto): Promise<Organization> {
    return this.organizationsService.create(data);
  }

  @Put(':id')
  @ApiBody({ type: UpdateOrganizationDto })
  @ApiResponse({ status: 200, description: 'Organization updated', type: Organization })
  update(@Param('id') id: number, @Body() data: UpdateOrganizationDto): Promise<Organization> {
    return this.organizationsService.update(id, data);
  }

  @Delete(':id')
  @ApiResponse({ status: 204, description: 'Organization deleted' })
  remove(@Param('id') id: number): Promise<void> {
    return this.organizationsService.remove(id);
  }
}
