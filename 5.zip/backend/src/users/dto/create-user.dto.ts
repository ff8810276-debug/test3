import { ApiProperty } from '@nestjs/swagger';

export class CreateUserDto {
  @ApiProperty({ example: 'John' })
  firstName: string;

  @ApiProperty({ example: 'Doe' })
  lastName: string;

  @ApiProperty({ example: 'john@example.com' })
  email: string;

  @ApiProperty({ example: '123456' })
  password: string;

  @ApiProperty({ required: false, example: '09120000000' })
  phone?: string;

  @ApiProperty({ enum: ['ADMIN', 'MANAGER', 'EMPLOYEE'], default: 'EMPLOYEE' })
  role?: 'ADMIN' | 'MANAGER' | 'EMPLOYEE';

  @ApiProperty({ required: false, example: 'Developer' })
  position?: string;

  @ApiProperty({ example: 1, description: 'Organization ID' })
  organizationId: number;
}
