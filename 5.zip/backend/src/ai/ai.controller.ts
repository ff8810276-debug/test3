import { Controller, Post, Body } from '@nestjs/common';
import { AiService } from './ai.service';

@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('suggest')
  async suggest(@Body('role') role: string) {
    const skills = await this.aiService.suggestSkills(role);
    return { role, skills };
  }
}
