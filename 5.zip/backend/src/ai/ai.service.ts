import { Injectable } from '@nestjs/common';
import fetch from 'node-fetch';

@Injectable()
export class AiService {
  private ollamaUrl = 'http://localhost:11434/api/generate';

  async suggestSkills(role: string): Promise<string[]> {
    const prompt = `
Your only task: when I give you a job role, respond ONLY with a bullet list of the skills required for that role.
No descriptions. No extra text. Only skills.

Job role: ${role}
    `;

    const response = await fetch(this.ollamaUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3:8b',
        prompt,
        stream: false, // 👈 مهم: استریم را خاموش می‌کنیم
      }),
    });

    const text = await response.text();

    // Ollama معمولاً خروجی Stream مانند برمی‌گرداند → پارس ساده:
    const cleaned = text
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('{') && !l.startsWith('}'));

    return cleaned
      .map((line) => line.replace(/^[-•]\s*/, ''))
      .filter((line) => line.length > 1);
  }
}
