import { Controller, Get, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { YoutubeService } from './youtube.service';
import * as jwt from 'jsonwebtoken';

@Controller('youtube')
export class YoutubeController {
  constructor(private readonly youtubeService: YoutubeService) {}

  @Get('search')
  async search(@Query('q') query: string, @Query('pageToken') pageToken?: string) {
    return this.youtubeService.searchVideos(query, pageToken);
  }

  @Get('videos')
  async getVideo(@Query('id') id: string, @Req() req: Request) {
    let userId: number | undefined;
    const token = req.cookies['accessToken'];

    if (token) {
      try {
        const decoded: any = jwt.verify(token, 'SECRET_KEY'); // یا از env بخون
        userId = decoded.sub;
      } catch (err) {
        console.warn('Invalid JWT token');
      }
    }

    return this.youtubeService.getVideoById(id, userId);
  }
}
