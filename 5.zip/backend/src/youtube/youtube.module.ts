// src/youtube/youtube.module.ts
import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { YoutubeService } from './youtube.service';
import { YoutubeController } from './youtube.controller';
import { UserActivityModule } from '../user-activity/user-activity.module';

@Module({
  imports: [
    HttpModule,
    UserActivityModule,
  ],
  providers: [YoutubeService],
  controllers: [YoutubeController],
})
export class YoutubeModule {}
