import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Organization } from './organization.entity';
import { CreateOrganizationDto } from './dto/create-organization.dto';
import { UpdateOrganizationDto } from './dto/update-organization.dto';

@Injectable()
export class OrganizationsService {
  constructor(
    @InjectRepository(Organization)
    private orgRepository: Repository<Organization>,
  ) {}

  findAll(): Promise<Organization[]> {
    return this.orgRepository.find({ relations: ['users'] });
  }

  async findOne(id: number): Promise<Organization> {
    const org = await this.orgRepository.findOne({
      where: { id },
      relations: ['users'],
    });
    if (!org) throw new NotFoundException('Organization not found');
    return org;
  }

  async create(data: CreateOrganizationDto): Promise<Organization> {
    const newOrg = this.orgRepository.create(data);
    return this.orgRepository.save(newOrg);
  }

  async update(id: number, data: UpdateOrganizationDto): Promise<Organization> {
    const org = await this.findOne(id);
    Object.assign(org, data);
    return this.orgRepository.save(org);
  }

  async remove(id: number): Promise<void> {
    const org = await this.findOne(id);
    await this.orgRepository.remove(org);
  }
}
