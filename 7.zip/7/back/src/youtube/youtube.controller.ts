import { Controller, Get, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { YoutubeService } from './youtube.service';
import * as jwt from 'jsonwebtoken';

@Controller('youtube')
export class YoutubeController {
  constructor(private readonly youtubeService: YoutubeService) {}

  @Get('search')
  async search(@Query('q') query: string, @Query('pageToken') pageToken?: string) {
    return this.youtubeService.searchVideos(query, pageToken);
  }

@Get('videos')
async getVideo(@Query('id') id: string, @Req() req: Request) {
  console.log("\n========== YOUTUBE VIDEO REQUEST ==========");
  console.log("Headers:", req.headers);
  console.log("Cookies:", req.cookies);
  console.log("Authorization:", req.headers['authorization']);
  console.log("Access Token (cookie):", req.cookies['accessToken']);
  console.log("==========================================\n");

  let userId: number | undefined;
  let token: string | undefined;

  // 1) TRY HEADER FIRST
  if (req.headers['authorization']) {
    token = req.headers['authorization'].replace('Bearer ', '');
  }

  // 2) OR COOKIE FALLBACK
  if (!token && req.cookies['accessToken']) {
    token = req.cookies['accessToken'];
  }

  if (token) {
    try {
      const decoded: any = jwt.verify(token, 'SECRET_KEY');
      userId = decoded.sub;
      console.log("✅ Decoded userId:", userId);
    } catch (err) {
      console.log("❌ Invalid JWT:", err.message);
    }
  } else {
    console.log("❌ No token found in header or cookie");
  }

  return this.youtubeService.getVideoById(id, userId);
}



}
