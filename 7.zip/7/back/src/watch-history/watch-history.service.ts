import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { WatchHistory } from './entities/watch-history.entity';

@Injectable()
export class WatchHistoryService {
  constructor(
    @InjectRepository(WatchHistory)
    private repo: Repository<WatchHistory>,
  ) {}

  async updateProgress(videoId: number, userId: number, seconds: number) {
    let record = await this.repo.findOne({
      where: { video: { id: videoId }, user: { id: userId } },
    });

    if (!record) {
      record = this.repo.create({
        video: { id: videoId } as any,
        user: { id: userId } as any,
        progressSeconds: seconds,
      });
    } else {
      record.progressSeconds = seconds;
    }

    return this.repo.save(record);
  }

  historyForUser(userId: number) {
    return this.repo.find({
      where: { user: { id: userId } },
      relations: ['video'],
      order: { updatedAt: 'DESC' },
    });
  }
}
