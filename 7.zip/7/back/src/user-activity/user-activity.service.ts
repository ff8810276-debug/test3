import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserActivity } from './entities/user-activity.entity';
import { CreateUserActivityDto } from './dto/create-user-activity.dto';
import { UpdateUserActivityDto } from './dto/update-user-activity.dto';

@Injectable()
export class UserActivityService {
  constructor(
    @InjectRepository(UserActivity)
    private readonly activityRepository: Repository<UserActivity>,
  ) {}

  findAll(): Promise<UserActivity[]> {
    return this.activityRepository.find({ relations: ['user'] });
  }

  async findOne(id: number): Promise<UserActivity> {
    const activity = await this.activityRepository.findOne({
      where: { id },
      relations: ['user'],
    });
    if (!activity) throw new NotFoundException('Activity not found');
    return activity;
  }

async create(dto: CreateUserActivityDto): Promise<UserActivity> {
  const activity = this.activityRepository.create({
    user: { id: dto.userId } as any,
    action: dto.action,
    targetType: dto.targetType,
    targetId: dto.targetId,
    meta: dto.meta || {},
  });

  return this.activityRepository.save(activity);
}


  async update(id: number, dto: UpdateUserActivityDto): Promise<UserActivity> {
    const activity = await this.findOne(id);
    Object.assign(activity, dto);
    return this.activityRepository.save(activity);
  }

  async remove(id: number): Promise<void> {
    const activity = await this.findOne(id);
    await this.activityRepository.remove(activity);
  }

async log(
  userId: number,
  action: string,
  targetType: string,
  targetId?: string | number,
  meta: any = {},
) {
  return this.create({
    userId,
    action,
    targetType,
    targetId: targetId ? String(targetId) : undefined,
    meta,
  });
}



}
