import { Controller, Post, Delete, Get, Param, UseGuards, Req } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { VideoLikesService } from './video-likes.service';
import {
  ApiTags,
  ApiBearerAuth,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiResponse,
} from '@nestjs/swagger';
import { VideoLike } from './entities/video-like.entity';

@ApiTags('Video Likes')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('video-likes')
export class VideoLikesController {
  constructor(private readonly service: VideoLikesService) {}

  // -------------------------
  // LIKE
  // -------------------------
  @Post(':id')
  @ApiCreatedResponse({
    description: 'User liked the video',
    type: VideoLike,
  })
  like(@Param('id') videoId: number, @Req() req) {
    return this.service.like(videoId, req.user.userId);
  }

  // -------------------------
  // UNLIKE
  // -------------------------
  @Delete(':id')
  @ApiOkResponse({
    description: 'User unliked the video',
    schema: { example: { message: 'Unliked' } },
  })
  unlike(@Param('id') videoId: number, @Req() req) {
    return this.service.unlike(videoId, req.user.userId);
  }

  // -------------------------
  // GET COUNT OF LIKES
  // -------------------------
  @Get('count/:id')
  @ApiOkResponse({
    description: 'Number of likes for video',
    schema: { example: { videoId: 5, likes: 12 } },
  })
  async countLikes(@Param('id') videoId: number) {
    const count = await this.service.count(videoId);
    return { videoId, likes: count };
  }

  // -------------------------
  // CHECK IF USER LIKED VIDEO
  // -------------------------
  @Get('status/:id')
  @ApiOkResponse({
    description: 'Check if user liked the video',
    schema: { example: { liked: true } },
  })
  async isLiked(@Param('id') videoId: number, @Req() req) {
    const liked = await this.service.isLiked(videoId, req.user.userId);
    return { liked };
  }

@Get()
@ApiOkResponse({
  description: 'List of videos liked by user',
  schema: {
    example: [
      {
        id: 3,
        createdAt: "2025-01-01T12:00:00Z",
        video: {
          id: 10,
          title: "React Tutorial",
          imageUrl: "/uploads/images/123.png",
        }
      }
    ]
  }
})
likedVideos(@Req() req) {
  return this.service.getLikedVideos(req.user.userId);
}


}
