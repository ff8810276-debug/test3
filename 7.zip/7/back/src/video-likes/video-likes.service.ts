import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { VideoLike } from './entities/video-like.entity';

@Injectable()
export class VideoLikesService {
  constructor(
    @InjectRepository(VideoLike)
    private repo: Repository<VideoLike>,
  ) {}

  // LIKE
  async like(videoId: number, userId: number) {
    const exists = await this.repo.findOne({
      where: { video: { id: videoId }, user: { id: userId } },
    });

    if (exists) throw new ConflictException('Already liked');

    const like = this.repo.create({
      video: { id: videoId } as any,
      user: { id: userId } as any,
    });

    return this.repo.save(like);
  }

  // UNLIKE
  async unlike(videoId: number, userId: number) {
    const like = await this.repo.findOne({
      where: { video: { id: videoId }, user: { id: userId } },
    });

    if (!like) throw new NotFoundException('Like not found');

    await this.repo.remove(like);
    return { message: 'Unliked' };
  }

  // COUNT
  count(videoId: number) {
    return this.repo.count({ where: { video: { id: videoId } } });
  }

  // CHECK LIKE STATUS
  async isLiked(videoId: number, userId: number): Promise<boolean> {
    const exists = await this.repo.findOne({
      where: { video: { id: videoId }, user: { id: userId } },
    });

    return !!exists;
  }

async getLikedVideos(userId: number) {
  return this.repo.find({
    where: { user: { id: userId } },
    relations: ['video'],
    order: { createdAt: 'DESC' },
  });
}


}
