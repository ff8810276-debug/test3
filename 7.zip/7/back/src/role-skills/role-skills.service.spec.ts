import { Test, TestingModule } from '@nestjs/testing';
import { RoleSkillsService } from './role-skills.service';

describe('RoleSkillsService', () => {
  let service: RoleSkillsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RoleSkillsService],
    }).compile();

    service = module.get<RoleSkillsService>(RoleSkillsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
