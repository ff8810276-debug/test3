"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import Cookies from "js-cookie";

interface YoutubeVideo {
  id: string;
  snippet: {
    title: string;
    channelTitle: string;
    description: string;
    publishedAt: string;
    tags?: string[];
    thumbnails: any;
  };
  statistics: {
    viewCount: string;
    likeCount: string;
    commentCount: string;
  };
  contentDetails: {
    duration: string;
  };
}

interface LocalVideo {
  id: number;
  title: string;
  description: string;
  videoUrl: string;
  imageUrl: string | null;
  tags: string[];
  duration: string | null;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  createdAt: string;
}

const formatNumber = (num: any) =>
  Number(num).toLocaleString("fa-IR");

const formatDate = (d: string) =>
  new Date(d).toLocaleDateString("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

const formatDuration = (iso: string) => {
  if (!iso) return "";

  const regex = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
  const m = iso.match(regex);

  const h = Number(m?.[1] || 0);
  const min = Number(m?.[2] || 0);
  const s = Number(m?.[3] || 0);

  const pad = (n: number) => n.toString().padStart(2, "0");

  return h
    ? `${h}:${pad(min)}:${pad(s)}`
    : `${min}:${pad(s)}`;
};

export default function VideoPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const token = Cookies.get("accessToken");

  console.log('token =>', token)


  const videoId = params.videoId;
  const type = searchParams.get("type"); // youtube | local

  const [ytVideo, setYtVideo] = useState<YoutubeVideo | null>(null);
  const [localVideo, setLocalVideo] = useState<LocalVideo | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showFullDesc, setShowFullDesc] = useState(false);

  useEffect(() => {
    async function fetchVideo() {
      setLoading(true);
      setError(null);

      try {
        if (type === "youtube") {
          // ---- دریافت از یوتیوب ----
          const res = await fetch(`http://localhost:3001/youtube/videos?id=${videoId}`, {
            headers: {
              Authorization: `Bearer ${token}`
            },
          });
          if (!res.ok) throw new Error("خطا در دریافت ویدیو یوتیوب");

          const data = await res.json();
          setYtVideo(data.items[0]);
        } else {
          // ---- دریافت از لوکال ----
          const res = await fetch(`http://localhost:3001/videos/${videoId}`, {
            credentials: "include",   // ⬅⬅⬅ مهم

            headers: {
              Authorization: `Bearer ${token}`
            },
          });
          if (!res.ok) throw new Error("خطا در دریافت ویدیو لوکال");

          const data = await res.json();
          setLocalVideo(data);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchVideo();
  }, [videoId, type]);

  if (loading) return <p className="text-center mt-10">در حال بارگذاری...</p>;
  if (error) return <p className="text-center mt-10 text-red-500">{error}</p>;

  // اگر ویدیو لوکال است:
  if (type === "local" && localVideo) {
    return (
      <section className="container mx-auto px-4 py-10">
        <Link href="/" className="text-blue-500 underline mb-4 inline-block">
          ← بازگشت
        </Link>

        <h1 className="text-3xl font-bold mb-3">{localVideo.title}</h1>

        <div className="flex gap-4 mb-4 text-gray-600 dark:text-gray-400">
          <span>👁‍🗨 {formatNumber(localVideo.viewCount)} بازدید</span>
          <span>👍 {formatNumber(localVideo.likeCount)} لایک</span>
          <span>💬 {formatNumber(localVideo.commentCount)} نظر</span>
        </div>

        <video
          className="w-full h-96 md:h-[500px] rounded-xl bg-black mb-6"
          controls
          src={`http://localhost:3001${localVideo.videoUrl}`}
        />

        {localVideo.tags && (
          <div className="flex flex-wrap gap-2 mb-6">
            {localVideo.tags.map((t) => (
              <span key={t} className="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-full text-sm">
                #{t}
              </span>
            ))}
          </div>
        )}

        <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg shadow">
          <p className="whitespace-pre-line leading-7">
            {showFullDesc
              ? localVideo.description
              : localVideo.description.substring(0, 300) + " ..."}
          </p>

          <button
            onClick={() => setShowFullDesc(!showFullDesc)}
            className="text-blue-500 mt-3"
          >
            {showFullDesc ? "نمایش کمتر" : "نمایش کامل توضیحات"}
          </button>
        </div>
      </section>
    );
  }

  // اگر یوتیوب است:
  if (type === "youtube" && ytVideo) {
    const snippet = ytVideo.snippet;
    const stats = ytVideo.statistics;
    const details = ytVideo.contentDetails;

    return (
      <section className="container mx-auto px-4 py-10">

        <Link href="/" className="text-blue-500 underline mb-4 inline-block">
          ← بازگشت
        </Link>

        <h1 className="text-3xl font-bold mb-3">{snippet.title}</h1>

        <div className="text-gray-600 dark:text-gray-400 mb-4">
          {snippet.channelTitle} • {formatDate(snippet.publishedAt)}
        </div>

        <div className="flex gap-4 text-gray-700 dark:text-gray-300 mb-6">
          <span>👁‍🗨 {formatNumber(stats.viewCount)} بازدید</span>
          <span>👍 {formatNumber(stats.likeCount)} لایک</span>
          <span>💬 {formatNumber(stats.commentCount)} نظر</span>
          <span>⏱ {formatDuration(details.duration)}</span>
        </div>

        <iframe
          className="w-full h-96 md:h-[500px] rounded-xl shadow mb-6"
          src={`https://www.youtube.com/embed/${ytVideo.id}`}
          allowFullScreen
        />

        {snippet.tags && (
          <div className="flex flex-wrap gap-2 mb-6">
            {snippet.tags.map((t) => (
              <span key={t} className="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-full text-sm">
                #{t}
              </span>
            ))}
          </div>
        )}

        <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg shadow">
          <p className="whitespace-pre-line leading-7">
            {showFullDesc
              ? snippet.description
              : snippet.description.substring(0, 300) + " ..."}
          </p>

          <button
            onClick={() => setShowFullDesc(!showFullDesc)}
            className="text-blue-500 mt-3"
          >
            {showFullDesc ? "نمایش کمتر" : "نمایش کامل توضیحات"}
          </button>
        </div>
      </section>
    );
  }

  return null;
}
