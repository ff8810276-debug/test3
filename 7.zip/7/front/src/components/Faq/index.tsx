import SectionTitle from "../Common/SectionTitle";
import SingleFaq from "./SingleFaq";

const Faq = () => {
  return (
    <section className="relative z-20 overflow-hidden bg-white pb-8 pt-20 dark:bg-dark lg:pb-[50px] lg:pt-[120px]">
      <div className="container">
        <SectionTitle
          subtitle="سوالات متداول"
          title="هر سوالی دارید؟ پاسخش اینجاست!"
          paragraph="ما اینجا هستیم تا تمام ابهامات شما را برطرف کنیم. اگر پاسخ سوالتان را پیدا نکردید، از طریق پشتیبانی با ما در ارتباط باشید."
          width="640px"
          center
        />

        <div className="-mx-4 mt-[60px] flex flex-wrap lg:mt-20">
          {/* ستون چپ */}
          <div className="w-full px-4 lg:w-1/2">
            <SingleFaq
              question="LXP چه تفاوتی با کلاس‌های تقویتی دارد؟"
              answer="LXP یک مربی هوشمند ۲۴ ساعته است که بر اساس عملکرد شما درس می‌دهد. نیازی به ساعت مشخص یا رفت‌وآمد نیست. آزمون‌های تطبیقی، ویدیوهای تعاملی و تحلیل دقیق پیشرفت، همه در یک پلتفرم."
            />
            <SingleFaq
              question="آیا LXP برای همه دروس مناسب است؟"
              answer="بله! LXP تمام دروس پایه‌های هفتم تا دوازدهم (ریاضی، فیزیک، شیمی، زیست، ادبیات، عربی و ...) را پوشش می‌دهد. همچنین برای کنکور سراسری و آزمون‌های نهایی آماده‌سازی کامل دارد."
            />
            <SingleFaq
              question="آیا می‌توانم پلن را لغو کنم؟"
              answer="کاملاً! اشتراک LXP ماهانه است و شما هر زمان که خواستید می‌توانید لغو کنید. بدون جریمه، بدون سوال. فقط کافی است از پنل کاربری اقدام کنید."
            />
          </div>

          {/* ستون راست */}
          <div className="w-full px-4 lg:w-1/2">
            <SingleFaq
              question="آیا پلن رایگان محدودیت زمانی دارد؟"
              answer="پلن رایگان برای همیشه در دسترس است! شما همیشه به ۳ درس آزمایشی و ۱۰ سوال در هفته با مربی هوشمند دسترسی دارید. بدون تاریخ انقضا."
            />
            <SingleFaq
              question="چطور پیشرفت فرزندم را ببینم؟"
              answer="در داشبورد والدین، گزارش هفتگی شامل زمان مطالعه، نمرات آزمون، نقاط قوت و ضعف و پیش‌بینی نمره نهایی نمایش داده می‌شود. همچنین اعلان‌های هوشمند دریافت می‌کنید."
            />
            <SingleFaq
              question="آیا LXP روی گوشی کار می‌کند؟"
              answer="بله! اپلیکیشن LXP برای اندروید و iOS موجود است. تمام امکانات وب‌سایت + اعلان‌های هوشمند، آزمون آفلاین و یادگیری در مسیر."
            />
          </div>
        </div>
      </div>

      {/* دکور پس‌زمینه (بدون تغییر) */}
      <div>
        <span className="absolute left-4 top-4 -z-[1]">
          <svg width="48" height="134" viewBox="0 0 48 134" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* ... (همان SVG قبلی) */}
          </svg>
        </span>
        <span className="absolute bottom-4 right-4 -z-[1]">
          <svg width="48" height="134" viewBox="0 0 48 134" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* ... (همان SVG قبلی) */}
          </svg>
        </span>
      </div>
    </section>
  );
};

export default Faq;