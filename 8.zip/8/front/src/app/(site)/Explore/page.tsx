"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Cookies from "js-cookie";

type PostType = {
  id: string | number;
  videoId: string | number;
  isYoutube: boolean;
  image: string;
  title: string;
  channel?: string;
  views?: string;
  uploaded?: string;
  likes: number;
  comments: number;
  source: string;
};

const Explore = () => {
  const [posts, setPosts] = useState<PostType[]>([]);
  const token = Cookies.get("accessToken");

  useEffect(() => {
    const fetchExplore = async () => {
      const res = await fetch("http://localhost:3001/explore/for-user", {
        credentials: "include",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      console.log("EXPLORE DATA =>", data);

      // LOCAL — SKILL
      const skillPosts: PostType[] = (data.skillBased || []).map((item: any) => ({
        id: item.id,
        videoId: item.id,
        isYoutube: false,
        source: "skill",
        image: item.imageUrl || "http://localhost:3001/uploads/images/default.webp",
        title: item.title,
        channel: "مرتبط با مهارت‌های شما",
        views: item.viewCount + "",
        uploaded: item.createdAt,
        likes: item.likeCount,
        comments: item.commentCount,
      }));

      // LOCAL — ROLE
      const rolePosts: PostType[] = (data.roleBased || []).map((item: any) => ({
        id: item.id,
        videoId: item.id,
        isYoutube: false,
        source: "role",
        image: item.imageUrl || "http://localhost:3001/uploads/images/default.webp",
        title: item.title,
        channel: "محبوب بین هم‌نقشی‌ها",
        views: item.viewCount + "",
        uploaded: item.createdAt,
        likes: item.likeCount,
        comments: item.commentCount,
      }));

      // LOCAL — TRENDING
      const trendingPosts: PostType[] = (data.trending || []).map((item: any) => ({
        id: item.id,
        videoId: item.id,
        isYoutube: false,
        source: "trending",
        image: item.imageUrl || "http://localhost:3001/uploads/images/default.webp",
        title: item.title,
        channel: "ویدیوهای ترند",
        views: item.viewCount + "",
        uploaded: item.createdAt,
        likes: item.likeCount,
        comments: item.commentCount,
      }));

      // YOUTUBE — SKILL
      const youtubeSkill: PostType[] = (data.youtubeSkill || [])
        .filter((item: any) => item.id?.videoId)
        .map((item: any) => ({
          id: item.id.videoId,
          videoId: item.id.videoId,
          isYoutube: true,
          source: "youtube-skill",
          image: item.snippet.thumbnails.high.url,
          title: item.snippet.title,
          channel: item.snippet.channelTitle,
          views: Math.floor(Math.random() * 200) + "K",
          uploaded: item.snippet.publishTime,
          likes: Math.floor(Math.random() * 5000),
          comments: Math.floor(Math.random() * 300),
        }));

      // YOUTUBE — ROLE
      const youtubeRole: PostType[] = (data.youtubeRole || []).map((item: any) => ({
        id: item.id,
        videoId: item.id,
        isYoutube: true,
        source: "youtube-role",
        image: item.snippet.thumbnails.high.url,
        title: item.snippet.title,
        channel: item.snippet.channelTitle,
        views: item.statistics?.viewCount || "0",
        uploaded: item.snippet.publishedAt,
        likes: item.statistics?.likeCount || 0,
        comments: item.statistics?.commentCount || 0,
      }));

      // MERGE ALL VIDEOS
      let merged = [
        ...skillPosts,
        ...rolePosts,
        ...trendingPosts,
        ...youtubeSkill,
        ...youtubeRole,
      ];

      // 🔥 حذف ویدیوهای تکراری (local + youtube)
      merged = merged.filter(
        (video, index, self) =>
          index === self.findIndex((v) => v.videoId === video.videoId)
      );

      setPosts(merged);
    };

    fetchExplore();
  }, []);

  return (
    <section className="pb-20 pt-24">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {posts.map((post) => {
            const key = `${post.source}-${post.videoId}`;

            return (
              <div key={key} className="cursor-pointer">
                <Link
                  href={
                    post.isYoutube
                      ? `/video/${post.videoId}?type=youtube`
                      : `/video/${post.videoId}?type=local`
                  }
                >
                  <div className="relative w-full aspect-video rounded-xl overflow-hidden group">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Link>

                <div className="mt-2">
                  <h3 className="text-sm font-bold text-white line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="text-xs text-gray-400 mt-1">{post.channel}</p>

                  <p className="text-xs text-gray-500">
                    {post.views} بازدید •{" "}
                    {post.uploaded &&
                      new Date(post.uploaded).toLocaleDateString("fa-IR")}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Explore;
