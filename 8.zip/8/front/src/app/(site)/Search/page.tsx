'use client';

import { useState } from "react";
import Link from "next/link";

type PostType = {
  id: string | number;
  videoId: string | number;
  isYoutube: boolean;

  image: string;
  title: string;
  channel?: string;
  uploaded?: string;
  views?: string;

  likes: number;
  comments: number;
};

const SearchPage = () => {
  const [posts, setPosts] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState("");

  async function searchVideos() {
    if (!inputValue.trim()) return;

    setLoading(true);

    const url = `http://localhost:3001/search?q=${encodeURIComponent(inputValue)}`;
    const res = await fetch(url);

    const data = await res.json();
    console.log("SEARCH DATA =>", data);

    // --------- یو تیوب ----------
    const youtubePosts = data.youtube.map((yt: any) => ({
      id: yt.id.videoId,
      videoId: yt.id.videoId,
      isYoutube: true,

      image: yt.snippet.thumbnails.high.url,
      title: yt.snippet.title,
      channel: yt.snippet.channelTitle,
      uploaded: yt.snippet.publishTime,
      views: "100K",

      likes: Math.floor(Math.random() * 1000),
      comments: Math.floor(Math.random() * 300),
    }));

    // --------- لوکال ----------
    const localPosts = data.local.map((v: any) => ({
      id: v.id,
      videoId: v.id,
      isYoutube: false,

      image: v.imageUrl || "/default-image.jpg",
      title: v.title,
      channel: "Local Video",
      uploaded: v.createdAt,
      views: v.viewCount + "",

      likes: v.likeCount ?? 0,
      comments: v.commentCount ?? 0,
    }));

    // ترکیب نهایی
    setPosts([...localPosts, ...youtubePosts]);

    setLoading(false);
  }

  return (
    <section className="bg-gray-50 dark:bg-dark pb-10 pt-20 lg:pb-20 lg:pt-[120px]">
      <div className="container mx-auto px-4">

        {/* Input */}
        <div className="mb-12">
          <div className="relative mx-auto max-w-2xl">
            <input
              type="text"
              placeholder="جستجو کنید (مثلاً React یا Python)"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchVideos()}
              className="w-full rounded-full border border-gray-300 bg-white py-3 pr-12 pl-6 text-base text-gray-900 shadow-sm dark:bg-dark-2 dark:text-white"
            />
          </div>
        </div>

        {/* Result Grid */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
          {posts.map((post) => (
            <div key={post.id}>

              <Link
                href={
                  post.isYoutube
                    ? `/video/${post.videoId}?type=youtube`
                    : `/video/${post.videoId}?type=local`
                }
              >
                <div className="relative w-full aspect-video rounded-xl overflow-hidden group">

                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />

                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="text-white flex gap-4 text-lg">
                      ❤️ {post.likes}
                      💬 {post.comments}
                    </div>
                  </div>

                </div>
              </Link>

              <div className="mt-2">
                <h3 className="text-sm font-bold text-white line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-xs text-gray-400">{post.channel}</p>
                <p className="text-xs text-gray-500">
                  {post.views} views •{" "}
                  {new Date(post.uploaded).toLocaleDateString("fa-IR")}
                </p>
              </div>

            </div>
          ))}
        </div>

        {loading && (
          <p className="text-center text-white mt-6">در حال جستجو...</p>
        )}

      </div>
    </section>
  );
};

export default SearchPage;
