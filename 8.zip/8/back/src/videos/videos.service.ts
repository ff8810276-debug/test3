import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Video } from './entities/video.entity';
import { CreateVideoDto } from './dto/create-video.dto';
import { ACTIVITY, TARGET } from '../user-activity/activity.constants';

import { UserActivityService } from '../user-activity/user-activity.service';

@Injectable()
export class VideosService {
  constructor(
    @InjectRepository(Video)
    private readonly videoRepo: Repository<Video>,

    private readonly activityService: UserActivityService, // ✅ اضافه شد
  ) { }

  findAll(): Promise<Video[]> {
    return this.videoRepo.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: number, userId?: number): Promise<Video> {
    const video = await this.videoRepo.findOne({ where: { id } });
    if (!video) throw new NotFoundException('Video not found');

    // افزایش بازدید
    video.viewCount += 1;
    await this.videoRepo.save(video);

    // ثبت اکتیویتی
  if (userId) {
  await this.activityService.create({
    userId,
    action: 'VIEW_VIDEO',
    targetType: 'LOCAL_VIDEO',
    targetId: String(video.id),
    meta: {
      title: video.title,
      thumbnail: video.imageUrl,
      tags: video.tags,
      duration: video.duration,
    }
  });
}


    return video;
  }

  create(dto: CreateVideoDto): Promise<Video> {
    const video = this.videoRepo.create(dto);
    return this.videoRepo.save(video);
  }

  async update(id: number, dto: Partial<CreateVideoDto>): Promise<Video> {
    const video = await this.findOne(id);
    Object.assign(video, dto);
    return this.videoRepo.save(video);
  }

  async remove(id: number): Promise<void> {
    const video = await this.findOne(id);
    await this.videoRepo.remove(video);
  }
}
