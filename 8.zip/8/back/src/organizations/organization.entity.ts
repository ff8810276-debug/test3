import { ApiProperty } from '@nestjs/swagger';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';

@Entity('organizations')
export class Organization {
  @ApiProperty({ example: 1 })
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'TechCorp' })
  @Column()
  name: string;

  @ApiProperty({ example: 'contact@techcorp.com', required: false })
  @Column({ nullable: true })
  email?: string;

  @ApiProperty({ example: '+1-202-555-0188', required: false })
  @Column({ nullable: true })
  phone?: string;

  @ApiProperty({ example: '123 Tech Street, NY', required: false })
  @Column({ nullable: true })
  address?: string;

  @ApiProperty({ type: () => [User], required: false })
  @OneToMany(() => User, (user) => user.organization)
  users: User[];

  @ApiProperty({ example: '2025-01-01T00:00:00Z' })
  @CreateDateColumn()
  createdAt: Date;

  @ApiProperty({ example: '2025-01-01T00:00:00Z' })
  @UpdateDateColumn()
  updatedAt: Date;
}
