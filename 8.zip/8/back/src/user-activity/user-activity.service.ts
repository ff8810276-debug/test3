// src/user-activity/user-activity.service.ts

import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserActivity } from './entities/user-activity.entity';
import { CreateUserActivityDto } from './dto/create-user-activity.dto';
import { User } from '../users/user.entity';

@Injectable()
export class UserActivityService {
  constructor(
    @InjectRepository(UserActivity)
    private readonly activityRepository: Repository<UserActivity>,

    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) { }

  findAll(): Promise<UserActivity[]> {
    return this.activityRepository.find({ relations: ['user'] });
  }

  async findOne(id: number): Promise<UserActivity> {
    const activity = await this.activityRepository.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!activity) throw new NotFoundException('Activity not found');
    return activity;
  }

  async create(dto: CreateUserActivityDto): Promise<UserActivity> {
    const activity = this.activityRepository.create({
      user: { id: dto.userId } as any,
      action: dto.action,
      targetType: dto.targetType,
      targetId: dto.targetId,
      meta: dto.meta || {},
    });

    return this.activityRepository.save(activity);
  }

  async update(id: number, dto: any): Promise<UserActivity> {
    const activity = await this.findOne(id);
    Object.assign(activity, dto);
    return this.activityRepository.save(activity);
  }

  async remove(id: number): Promise<void> {
    const activity = await this.findOne(id);
    await this.activityRepository.remove(activity);
  }

  // ===========================================================
  // 🔥 1) لیست ویدیوهایی که "کاربر" دیده (LOCAL_VIDEO فقط)
  // ===========================================================
  async getVideosWatchedByUser(userId: number): Promise<number[]> {
    const activities = await this.activityRepository.find({
      where: {
        user: { id: userId },
        action: 'VIEW_VIDEO',
        targetType: 'LOCAL_VIDEO',
      },
    });

    return activities.map((a) => Number(a.targetId));
  }

  // ===========================================================
  // 🔥 2) لیست ویدیوهایی که تمام کاربران همان نقش دیده‌اند
  // ===========================================================
  async getVideosWatchedByRole(role: string): Promise<number[]> {
    // 1) کاربران این نقش را پیدا می‌کنیم
    const users = await this.userRepo.find({
      where: { role: role as 'ADMIN' | 'MANAGER' | 'EMPLOYEE' },
    });

    const userIds = users.map((u) => u.id);

    if (userIds.length === 0) return [];

    // 2) اکتیویتی همه کاربران این نقش را بگیریم
    const activities = await this.activityRepository
      .createQueryBuilder('a')
      .where('a.userId IN (:...ids)', { ids: userIds })
      .andWhere('a.action = :action', { action: 'VIEW_VIDEO' })
      .andWhere('a.targetType = :type', { type: 'LOCAL_VIDEO' })
      .getMany();

    // 3) لیست یکتا از ویدیوها
    const uniqueVideoIds = [...new Set(activities.map((a) => Number(a.targetId)))];

    return uniqueVideoIds;
  }
// ===========================================================
// 🔵 3) ویدیوهای یوتیوبی که یک کاربر دیده است
// ===========================================================
async getYouTubeVideosWatchedByUser(userId: number): Promise<string[]> {
  const activities = await this.activityRepository.find({
    where: {
      user: { id: userId },
      action: 'VIEW_VIDEO',
      targetType: 'YOUTUBE_VIDEO',
    },
  });

  return activities.map((a) => String(a.targetId));
}

// ===========================================================
// 🔵 4) ویدیوهای یوتیوبی که تمام کاربران یک Role دیده‌اند
// ===========================================================
async getYouTubeVideosWatchedByRole(role: string): Promise<string[]> {
  // کاربران این نقش را پیدا می‌کنیم
  const users = await this.userRepo.find({
    where: { role: role as 'ADMIN' | 'MANAGER' | 'EMPLOYEE' },
  });

  const userIds = users.map((u) => u.id);
  if (userIds.length === 0) return [];

  // اکتیویتی یوتیوب تمام کاربران نقش
  const activities = await this.activityRepository
    .createQueryBuilder('a')
    .where('a.userId IN (:...ids)', { ids: userIds })
    .andWhere('a.action = :action', { action: 'VIEW_VIDEO' })
    .andWhere('a.targetType = :type', { type: 'YOUTUBE_VIDEO' })
    .getMany();

  // خروجی یکتا
  const uniqueVideoIds = [...new Set(activities.map((a) => String(a.targetId)))];

  return uniqueVideoIds;
}

  
}
