// src/role-skills/role-skills.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { RoleSkill } from './entities/role-skill.entity';

@Injectable()
export class RoleSkillsService {
  constructor(
    @InjectRepository(RoleSkill)
    private repo: Repository<RoleSkill>,
  ) {}

  getSkillsForRole(role: string) {
    return this.repo.find({
      where: { role },
      relations: ['skill'],
    });
  }
}
