// src/explore/explore.service.ts

import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { ExploreSetting } from './entities/explore-setting.entity';
import { Video } from '../videos/entities/video.entity';
import { YoutubeService } from '../youtube/youtube.service';

import { User } from '../users/user.entity';
import { RoleSkill } from '../role-skills/entities/role-skill.entity';
import { UserActivityService } from '../user-activity/user-activity.service';
import { ACTIVITY, TARGET } from '../user-activity/activity.constants';

@Injectable()
export class ExploreService {
  constructor(
    @InjectRepository(ExploreSetting)
    private repo: Repository<ExploreSetting>,

    @InjectRepository(Video)
    private videoRepo: Repository<Video>,

    @InjectRepository(User)
    private userRepo: Repository<User>,

    @InjectRepository(RoleSkill)
    private roleSkillRepo: Repository<RoleSkill>,

    private youtubeService: YoutubeService,
    private activityService: UserActivityService,
  ) {}

  // =============================
  // Settings
  // =============================
  async getSettings() {
    let settings = await this.repo.findOne({ where: { id: 1 } });

    if (!settings) {
      settings = this.repo.create({});
      settings = await this.repo.save(settings);
    }

    return settings;
  }

  async updateSettings(data: Partial<ExploreSetting>) {
    const settings = await this.getSettings();
    Object.assign(settings, data);
    return this.repo.save(settings);
  }

  // =============================
  // Explore عمومی
  // =============================
  async getExploreVideos() {
    const settings = await this.getSettings();
    const keyword = settings.keyword.toLowerCase();

    const result: {
      local: Video[];
      youtube: any[];
    } = { local: [], youtube: [] };

    // Local
    if (settings.allowLocal) {
      const videos = await this.videoRepo.find();
      result.local = videos.filter(
        (v) =>
          (v.tags && v.tags.includes(keyword)) ||
          v.title.toLowerCase().includes(keyword),
      );
    }

    // YouTube
    if (settings.allowYoutube) {
      const yt = await this.youtubeService.searchVideos(keyword);
      result.youtube = yt.items ?? [];
    }

    return result;
  }

  // ===========================================================
  // ⭐ Explore مخصوص کاربر — ترکیب Skills + Role + Activity + YouTube
  // ===========================================================
  async getExploreVideosForUser(userId: number) {
    // -----------------------
    // User
    // -----------------------
    const user = await this.userRepo.findOne({ where: { id: userId } });

    if (!user) throw new UnauthorizedException('User not found');

    const role = user.role;

    // -----------------------
    // Skills از Role
    // -----------------------
    const roleSkills = await this.roleSkillRepo.find({
      where: { role: user.role },
      relations: ['skill'],
    });

    const skills = roleSkills.map((rs) => rs.skill.name.toLowerCase());

    const allVideos = await this.videoRepo.find();

    // -----------------------
    // 1) Skill-Based (Local)
    // -----------------------
    const skillBased = allVideos.filter((v) =>
      (v.tags || []).some((tag) => skills.includes(tag.toLowerCase())),
    );

    // -----------------------
    // 2) Role-Based (Local)
    // -----------------------
    const watchedByRole = await this.activityService.getVideosWatchedByRole(role);
    const watchedByMe = await this.activityService.getVideosWatchedByUser(userId);

    const roleBased = allVideos.filter(
      (v) => watchedByRole.includes(v.id) && !watchedByMe.includes(v.id),
    );

    // -----------------------
    // 3) Trending (Local)
    // -----------------------
    const trending = [...allVideos]
      .sort((a, b) => b.viewCount - a.viewCount)
      .slice(0, 10);

    // -----------------------
    // 4) YouTube Based on Skills
    // -----------------------
    const youtubeSkill: any[] = [];
    for (const skill of skills) {
      const yt = await this.youtubeService.searchVideos(skill);
      youtubeSkill.push(...(yt.items ?? []));
    }

    // -----------------------
    // 5) YouTube Based on Role (ویدیوهایی که هم‌نقش‌ها دیده‌اند)
    // -----------------------
    const youtubeRoleIds =
      await this.activityService.getYouTubeVideosWatchedByRole(role);

    const youtubeRole: any[] = [];
    for (const id of youtubeRoleIds) {
      const yt = await this.youtubeService.getVideoById(id);
      if (yt?.items?.length > 0) youtubeRole.push(yt.items[0]);
    }

    // حذف مواردی که خود کاربر دیده
    const youtubeSeenByMe =
      await this.activityService.getYouTubeVideosWatchedByUser(userId);

    const youtubeRoleFiltered = youtubeRole.filter(
      (yt) => !youtubeSeenByMe.includes(yt.id),
    );

    // ================================
    // خروجی نهایی
    // ================================
    return {
      skills,
      skillBased,
      roleBased,
      trending,
      youtubeSkill,
      youtubeRole: youtubeRoleFiltered,
    };
  }
}
