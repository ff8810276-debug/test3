// src/explore/explore.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { ExploreSetting } from './entities/explore-setting.entity';
import { ExploreService } from './explore.service';
import { ExploreController } from './explore.controller';

import { YoutubeModule } from '../youtube/youtube.module';
import { Video } from '../videos/entities/video.entity';
import { User } from '../users/user.entity';
import { RoleSkill } from '../role-skills/entities/role-skill.entity';
import { UserActivityModule } from '../user-activity/user-activity.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ExploreSetting,
      Video,
      User,
      RoleSkill,
    ]),
    YoutubeModule,
    UserActivityModule, // 🔥 لازم است برای Role-Based Recommend
  ],
  controllers: [ExploreController],
  providers: [ExploreService],
  exports: [ExploreService],
})
export class ExploreModule {}
