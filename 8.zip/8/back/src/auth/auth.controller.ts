import { Controller, Post, Body, UseGuards, Req } from '@nestjs/common';
import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ApiTags, ApiBody, ApiResponse, ApiBearerAuth, ApiOkResponse } from '@nestjs/swagger';
import { User } from '../users/user.entity';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  @Post('register')
  @ApiBody({ type: RegisterDto })
  @ApiResponse({ status: 201, description: 'User registered', type: User })
  register(@Body() dto: RegisterDto) {
    return this.authService.register(dto);
  }

@Post('me')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth()
@ApiOkResponse({ description: 'Current logged user info', type: User }) 
me(@Req() req: any) {
  return this.authService.getMe(req.user.userId);
}

  @Post('login')
  @ApiBody({ type: LoginDto })
  @ApiResponse({ status: 200, description: 'User logged in, JWT returned' })
  login(@Body() dto: LoginDto) {
    return this.authService.login(dto);
  }


}
