// src/youtube/youtube.service.ts
import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { Api } from './key';
import { UserActivityService } from '../user-activity/user-activity.service';
import { CreateUserActivityDto } from '../user-activity/dto/create-user-activity.dto';
import { ACTIVITY, TARGET } from '../user-activity/activity.constants';

@Injectable()
export class YoutubeService {
  private readonly API_KEY = Api;

  constructor(
    private readonly httpService: HttpService,
    private readonly activityService: UserActivityService,
  ) {}

  async searchVideos(query: string, pageToken: string = '') {
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=12&q=${encodeURIComponent(query)}&key=${this.API_KEY}&pageToken=${pageToken}`;
    const response$ = this.httpService.get(url);
    const response = await firstValueFrom(response$);
    return response.data;
  }

async getVideoById(id: string, userId?: number) {
  const url = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${id}&key=${this.API_KEY}`;
  const response$ = this.httpService.get(url);
  const response = await firstValueFrom(response$);

  // ثبت فعالیت کاربر اگر userId موجود باشد
if (userId) {
await this.activityService.create({
  userId: userId,
  action: 'VIEW_VIDEO',
  targetType: 'YOUTUBE_VIDEO',
  targetId: id,
  meta: { source: 'youtube' }
});


}


  return response.data;
}

}
