import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // فعال کردن CORS
  app.enableCors({
    origin: 'http://localhost:3000', // آدرس فرانت‌اند
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true, // اگر از کوکی یا احراز هویت استفاده می‌کنید
  });

  const config = new DocumentBuilder()
    .setTitle('Organization & User Management API')
    .setDescription('API documentation for managing organizations and users')
    .setVersion('1.0')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);

  await app.listen(process.env.PORT ?? 3001);
  console.log('✅ Server is running on port 3001');
  console.log('📘 Swagger available at http://localhost:3001/api');
}
bootstrap();
