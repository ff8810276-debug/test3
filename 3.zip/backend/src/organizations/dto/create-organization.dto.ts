import { ApiProperty } from '@nestjs/swagger';

export class CreateOrganizationDto {
  @ApiProperty({ example: 'TechCorp' })
  name: string;

  @ApiProperty({ required: false, example: 'contact@techcorp.com' })
  email?: string;

  @ApiProperty({ required: false, example: '+1-202-555-0188' })
  phone?: string;

  @ApiProperty({ required: false, example: '123 Tech Street, NY' })
  address?: string;
}
