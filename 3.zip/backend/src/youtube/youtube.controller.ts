// src/youtube/youtube.controller.ts
import { Controller, Get, Query } from '@nestjs/common';
import { YoutubeService } from './youtube.service';

@Controller('youtube') // مسیر پایه
export class YoutubeController {
  constructor(private readonly youtubeService: YoutubeService) {}

  @Get('search') // مسیر کامل: /youtube/search
  async search(
    @Query('q') query: string,
    @Query('pageToken') pageToken?: string,
  ) {
    return this.youtubeService.searchVideos(query, pageToken);
  }
}
