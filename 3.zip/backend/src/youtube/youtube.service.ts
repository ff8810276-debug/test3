import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { Api } from './key';

@Injectable()
export class YoutubeService {
  constructor(private readonly httpService: HttpService) {}

  private API_KEY = Api;

  async searchVideos(query: string, pageToken: string = '') {
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=12&q=${encodeURIComponent(query)}&key=${this.API_KEY}&pageToken=${pageToken}`;

    const response$ = this.httpService.get(url);
    const response = await firstValueFrom(response$);
    return response.data;
  }
}
