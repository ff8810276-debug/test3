'use client';

import { useState } from "react";

const SearchPage = () => {
  const [videos, setVideos] = useState([]);
  const [nextPageToken, setNextPageToken] = useState("");
  const [currentQuery, setCurrentQuery] = useState("");
  const [inputValue, setInputValue] = useState(""); // مقدار input
  const [loading, setLoading] = useState(false);

  async function fetchVideos(query: string, pageToken = "") {
    const url = `http://localhost:3001/youtube/search?q=${encodeURIComponent(query)}&pageToken=${pageToken}`;
    const res = await fetch(url);
    if (!res.ok) {
      const err = await res.json();
      alert(err.message || "خطا در دریافت ویدیوها");
      return { items: [], nextPageToken: "" };
    }
    return res.json();
  }

  async function searchVideos() {
    if (!inputValue.trim()) return; // اگر خالی بود، جستجو نکن
    setCurrentQuery(inputValue);
    setLoading(true);
    const data = await fetchVideos(inputValue);
    setVideos(data.items || []);
    setNextPageToken(data.nextPageToken || "");
    setLoading(false);
  }

  async function loadMore() {
    if (!nextPageToken) return;
    setLoading(true);
    const data = await fetchVideos(currentQuery, nextPageToken);
    setVideos((prev) => [...prev, ...(data.items || [])]);
    setNextPageToken(data.nextPageToken || "");
    setLoading(false);
  }

  return (
    <section className="bg-gray-50 dark:bg-dark pb-10 pt-20 lg:pb-20 lg:pt-[120px]">
      <div className="container mx-auto px-4">
        <div className="mb-12">
          <div className="relative mx-auto max-w-2xl">
            <input
              type="text"
              placeholder="جستجو کنید (مثلاً React یا Python)"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchVideos()}
              className="w-full rounded-full border border-gray-300 bg-white py-3 pr-12 pl-6 text-base text-gray-900 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-gray-600 dark:bg-dark-2 dark:text-white dark:placeholder-gray-400"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-1 md:grid-cols-3 lg:grid-cols-4 md:gap-2 lg:gap-3">
          {videos.map((video: any) => {
            const videoId = video.id.videoId;
            const title = video.snippet.title;
            return (
              <div key={videoId} className="w-full">
                <iframe
                  src={`https://www.youtube.com/embed/${videoId}`}
                  allowFullScreen
                  className="w-full h-64 rounded-lg"
                />
                <p>{title}</p>
              </div>
            );
          })}
        </div>

        {nextPageToken && (
          <div className="text-center mt-8">
            <button
              onClick={loadMore}
              className="p-2 bg-blue-500 text-white rounded"
              disabled={loading}
            >
              {loading ? "در حال بارگذاری..." : "نمایش بیشتر ⬇️"}
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default SearchPage;
