"use client";

import { useState, useMemo } from "react";
import {
  Users,
  Video,
  FileText,
  Settings,
  Search,
  Bell,
  Menu,
  X,
  Edit,
  Trash2,
  Plus,
  Shield,
  TrendingUp,
  Activity,
  Globe,
  Youtube,
  HardDrive,
  Upload,
  Link,
  Filter,
  ChevronDown,
  Mail,
  DollarSign,
  Lock,
  Palette,
  CreditCard,
  Ban,
  CheckCircle,
  BarChart3,
  PieChart,
  Download,
  Award,
  Star,
  UserPlus,
  LogOut,
  Image as ImageIcon,
  Languages,
  Zap,
  MessageSquare,
  FileQuestion,
  Clock,
  Eye,
  EyeOff,
} from "lucide-react";

// --- Types ---
type ContentSource = "database" | "youtube" | "google_drive" | "upload" | "external_link";
type UserRole = "student" | "instructor" | "admin" | "premium";

interface Content {
  id: number;
  title: string;
  type: "video" | "course" | "post" | "quiz" | "webinar";
  source: ContentSource;
  sourceId?: string;
  url?: string;
  views: number;
  status: "published" | "draft" | "archived";
  date: string;
  access: {
    everyone: boolean;
    students: boolean;
    instructors: boolean;
    premium: boolean;
    specificUsers: number[];
  };
  duration?: string;
  progress?: number;
  rating?: number;
}

interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  joined: string;
  courses: number;
  progress: number;
  active: boolean;
  lastLogin: string;
  revenue: number;
  badges: number;
  points: number;
}

interface SiteSettings {
  siteName: string;
  tagline: string;
  logo: string;
  maintenance: boolean;
  allowSignup: boolean;
  maxUploadSize: number;
  defaultLanguage: string;
  email: { host: string; port: number; from: string };
  payment: { stripe: string; paypal: boolean };
  analytics: { google: string };
  gamification: { pointsPerCourse: number; badgeThreshold: number };
}

// --- Fake Data ---
const contentData: Content[] = [
  {
    id: 1,
    title: "آموزش Next.js پیشرفته",
    type: "video",
    source: "youtube",
    sourceId: "dQw4w9WgXcQ",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    views: 12450,
    status: "published",
    date: "2025-11-05",
    duration: "2h 30m",
    progress: 68,
    rating: 4.8,
    access: { everyone: false, students: true, instructors: true, premium: false, specificUsers: [] },
  },
  {
    id: 2,
    title: "دوره کامل UX Design",
    type: "course",
    source: "database",
    views: 8920,
    status: "published",
    date: "2025-11-03",
    duration: "12h",
    progress: 45,
    rating: 4.9,
    access: { everyone: false, students: true, instructors: false, premium: true, specificUsers: [] },
  },
  {
    id: 3,
    title: "فایل PDF روانشناسی یادگیری",
    type: "post",
    source: "upload",
    url: "/uploads/psychology.pdf",
    views: 5670,
    status: "published",
    date: "2025-11-01",
    access: { everyone: true, students: true, instructors: true, premium: false, specificUsers: [] },
  },
  {
    id: 4,
    title: "وبینار هوش مصنوعی (لایو)",
    type: "webinar",
    source: "external_link",
    url: "https://zoom.us/j/123456789",
    views: 21000,
    status: "draft",
    date: "2025-10-28",
    access: { everyone: false, students: false, instructors: true, premium: false, specificUsers: [1, 3] },
  },
  {
    id: 5,
    title: "کوییز: تست دانش React",
    type: "quiz",
    source: "database",
    views: 3200,
    status: "published",
    date: "2025-10-20",
    access: { everyone: false, students: true, instructors: true, premium: false, specificUsers: [] },
  },
];

const userData: User[] = [
  {
    id: 1,
    name: "علی محمدی",
    email: "ali@example.com",
    role: "student",
    joined: "2025-10-15",
    courses: 5,
    progress: 75,
    active: true,
    lastLogin: "2025-11-08",
    revenue: 0,
    badges: 12,
    points: 2450,
  },
  {
    id: 2,
    name: "سارا کریمی",
    email: "sara@example.com",
    role: "instructor",
    joined: "2025-09-20",
    courses: 12,
    progress: 0,
    active: true,
    lastLogin: "2025-11-07",
    revenue: 1500,
    badges: 8,
    points: 1800,
  },
  {
    id: 3,
    name: "رضا احمدی",
    email: "reza@example.com",
    role: "admin",
    joined: "2025-01-10",
    courses: 0,
    progress: 0,
    active: false,
    lastLogin: "2025-10-01",
    revenue: 0,
    badges: 0,
    points: 0,
  },
  {
    id: 4,
    name: "نرگس حسینی",
    email: "narges@example.com",
    role: "premium",
    joined: "2025-11-01",
    courses: 3,
    progress: 45,
    active: true,
    lastLogin: "2025-11-09",
    revenue: 0,
    badges: 5,
    points: 900,
  },
];

const siteSettings: SiteSettings = {
  siteName: "LXP Academy",
  tagline: "آینده آموزش آنلاین",
  logo: "/logo.png",
  maintenance: false,
  allowSignup: true,
  maxUploadSize: 500,
  defaultLanguage: "fa",
  email: { host: "smtp.gmail.com", port: 587, from: "no-reply@lxp.com" },
  payment: { stripe: "sk_test_...", paypal: true },
  analytics: { google: "G-XXXXXX" },
  gamification: { pointsPerCourse: 100, badgeThreshold: 500 },
};

// --- Stats ---
const stats = [
  { label: "کاربران کل", value: 1284, change: "+24%", icon: Users, color: "blue" },
  { label: "درآمد ماهانه", value: "$45,231", change: "+12%", icon: DollarSign, color: "green" },
  { label: "دوره‌های فعال", value: 56, change: "-2%", icon: Video, color: "purple" },
  { label: "نرخ تکمیل", value: "78%", change: "+5%", icon: CheckCircle, color: "yellow" },
];

// --- Components ---
const TabIcon = ({ type }: { type: string }) => {
  const icons: Record<string, JSX.Element> = {
    overview: <Activity className="h-5 w-5" />,
    content: <FileText className="h-5 w-5" />,
    users: <Users className="h-5 w-5" />,
    analytics: <BarChart3 className="h-5 w-5" />,
    gamification: <Award className="h-5 w-5" />,
    settings: <Settings className="h-5 w-5" />,
  };
  return icons[type] || null;
};

const SourceIcon = ({ source }: { source: ContentSource }) => {
  const icons: Record<ContentSource, JSX.Element> = {
    database: <HardDrive className="h-4 w-4 text-green-600" />,
    youtube: <Youtube className="h-4 w-4 text-red-600" />,
    google_drive: <Globe className="h-4 w-4 text-blue-600" />,
    upload: <Upload className="h-4 w-4 text-purple-600" />,
    external_link: <Link className="h-4 w-4 text-gray-600" />,
  };
  return icons[source];
};

const AccessBadge = ({ access }: { access: Content["access"] }) => {
  const badges = [];
  if (access.everyone) badges.push({ label: "همه", color: "gray" });
  if (access.students) badges.push({ label: "دانشجو", color: "blue" });
  if (access.instructors) badges.push({ label: "مدرس", color: "purple" });
  if (access.premium) badges.push({ label: "پریمیوم", color: "yellow" });
  if (access.specificUsers.length) badges.push({ label: `${access.specificUsers.length} خاص`, color: "red" });

  return (
    <div className="flex flex-wrap gap-1">
      {badges.map((b, i) => (
        <span key={i} className={`px-2 py-0.5 text-xs rounded-full bg-${b.color}-100 text-${b.color}-800`}>
          {b.label}
        </span>
      ))}
    </div>
  );
};

const StatCard = ({ stat }: { stat: any }) => {
  const Icon = stat.icon;
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600">{stat.label}</p>
          <p className="text-2xl font-bold">{stat.value}</p>
          <p className={`text-sm ${stat.change.startsWith("+") ? "text-green-600" : "text-red-600"}`}>{stat.change}</p>
        </div>
        <Icon className={`h-8 w-8 text-${stat.color}-600`} />
      </div>
    </div>
  );
};

// --- Main Component ---
const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<"overview" | "content" | "users" | "analytics" | "gamification" | "settings">("overview");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<UserRole | "all">("all");
  const [selectedContent, setSelectedContent] = useState<Content | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const filteredContent = useMemo(() => {
    return contentData.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sourceId?.includes(searchQuery) ||
      item.url?.includes(searchQuery)
    );
  }, [searchQuery]);

  const filteredUsers = useMemo(() => {
    return userData.filter((user) =>
      (user.name.toLowerCase().includes(searchQuery.toLowerCase()) || user.email.includes(searchQuery)) &&
      (filterRole === "all" || user.role === filterRole)
    );
  }, [searchQuery, filterRole]);

  const tabs = [
    { id: "overview", label: "نمای کلی", icon: "overview" },
    { id: "content", label: "محتوا", count: contentData.length, icon: "content" },
    { id: "users", label: "کاربران", count: userData.length, icon: "users" },
    { id: "analytics", label: "تحلیل‌ها", icon: "analytics" },
    { id: "gamification", label: "گیمیفیکیشن", icon: "gamification" },
    { id: "settings", label: "تنظیمات", icon: "settings" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
   

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 right-0 z-40 w-64 bg-white dark:bg-gray-800 border-l transform transition-transform lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "translate-x-full"}`}>
        <div className="p-4">
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden mb-4 p-2 rounded hover:bg-gray-100">
            <X className="h-5 w-5" />
          </button>
          <nav className="space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as any); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 p-3 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === tab.id ? "bg-blue-100 text-blue-700 dark:bg-blue-900" : "hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                <TabIcon type={tab.icon} />
                <span>{tab.label}</span>
                {tab.count !== undefined && <span className="ml-auto">({tab.count})</span>}
              </button>
            ))}
          </nav>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 lg:hidden z-30" onClick={() => setSidebarOpen(false)} />}

      {/* Main Content */}
      <main className="pt-16 mt-[70px] p-4 lg:p-8">
        <div className="max-w-7xl mx-auto">

          {/* Overview */}
          {activeTab === "overview" && (
            <div className="">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {stats.map((s, i) => <StatCard key={i} stat={s} />)}
              </div>
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold mb-4">فعالیت‌های اخیر</h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center gap-3"><Zap className="h-4 w-4 text-yellow-500" /> علی دوره UX را تکمیل کرد</li>
                  <li className="flex items-center gap-3"><Star className="h-4 w-4 text-yellow-500" /> سارا محتوای جدید آپلود کرد</li>
                </ul>
              </div>
            </div>
          )}

          {/* Content */}
          {activeTab === "content" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">مدیریت محتوا</h2>
                <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg">
                  <Plus className="h-4 w-4" /> افزودن محتوا
                </button>
              </div>
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="جستجو..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                />
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-semibold">عنوان</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">نوع</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">منبع</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">دسترسی</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">بازدید</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredContent.map((item) => (
                      <tr key={item.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            {item.type === "video" && <Video className="h-4 w-4 text-blue-600" />}
                            {item.type === "course" && <FileText className="h-4 w-4 text-green-600" />}
                            {item.type === "quiz" && <FileQuestion className="h-4 w-4 text-purple-600" />}
                            <span className="font-medium">{item.title}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs">{item.type === "video" ? "ویدیو" : item.type === "course" ? "دوره" : "کوییز"}</td>
                        <td className="px-4 py-3"><SourceIcon source={item.source} /></td>
                        <td className="px-4 py-3"><AccessBadge access={item.access} /></td>
                        <td className="px-4 py-3">{item.views.toLocaleString()}</td>
                        <td className="px-4 py-3 text-right">
                          <button onClick={() => { setSelectedContent(item); setIsEditModalOpen(true); }} className="p-1 text-blue-600"><Edit className="h-4 w-4" /></button>
                          <button className="p-1 text-red-600"><Trash2 className="h-4 w-4" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Users */}
          {activeTab === "users" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">مدیریت کاربران</h2>
                <button className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg">
                  <UserPlus className="h-4 w-4" /> کاربر جدید
                </button>
              </div>
              <div className="mb-4 flex gap-4">
                <input
                  type="text"
                  placeholder="جستجو..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 p-2 border rounded-lg"
                />
                <select
                  value={filterRole}
                  onChange={(e) => setFilterRole(e.target.value as any)}
                  className="p-2 border rounded-lg"
                >
                  <option value="all">همه نقش‌ها</option>
                  <option value="student">دانشجو</option>
                  <option value="instructor">مدرس</option>
                  <option value="admin">ادمین</option>
                  <option value="premium">پریمیوم</option>
                </select>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-semibold">کاربر</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">نقش</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">دوره‌ها</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">پیشرفت</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">آخرین ورود</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">درآمد</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">بج‌ها</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                              {user.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium">{user.name}</p>
                              <p className="text-xs text-gray-500">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${user.role === "admin" ? "bg-red-100 text-red-800" : user.role === "instructor" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"}`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">{user.courses}</td>
                        <td className="px-4 py-3">{user.progress}%</td>
                        <td className="px-4 py-3 text-xs">{user.lastLogin}</td>
                        <td className="px-4 py-3">${user.revenue}</td>
                        <td className="px-4 py-3">{user.badges}</td>
                        <td className="px-4 py-3 text-right">
                          <button className="p-1 text-blue-600"><Edit className="h-4 w-4" /></button>
                          <button className="p-1 text-red-600"><Trash2 className="h-4 w-4" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Analytics */}
          {activeTab === "analytics" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">تحلیل‌ها</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4">بازدید محتوا</h3>
                  <div className="h-64 bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
                    <BarChart3 className="h-12 w-12 text-gray-400" />
                  </div>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4">نرخ تکمیل</h3>
                  <div className="h-64 bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
                    <PieChart className="h-12 w-12 text-gray-400" />
                  </div>
                </div>
              </div>
              <button className="mt-6 flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded">
                <Download className="h-4 w-4" /> دانلود گزارش
              </button>
            </div>
          )}

          {/* Gamification */}
          {activeTab === "gamification" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">گیمیفیکیشن</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Award className="h-5 w-5" /> بج‌ها
                  </h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2"><Star className="h-4 w-4 text-yellow-500" /> تکمیل 5 دوره</li>
                    <li className="flex items-center gap-2"><Star className="h-4 w-4 text-yellow-500" /> فعالیت ماهانه</li>
                  </ul>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4">لیدربورد</h3>
                  <ol className="space-y-2 text-sm">
                    <li className="flex justify-between">علی محمدی <span>2450 امتیاز</span></li>
                    <li className="flex justify-between">سارا کریمی <span>1800 امتیاز</span></li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {/* Settings */}
          {activeTab === "settings" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">تنظیمات</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Palette className="h-5 w-5" /> برندینگ
                  </h3>
                  <input defaultValue={siteSettings.siteName} className="w-full p-2 border rounded mb-2" />
                  <input defaultValue={siteSettings.tagline} className="w-full p-2 border rounded mb-2" />
                  <label className="flex items-center gap-2 cursor-pointer">
                    <ImageIcon className="h-5 w-5" />
                    <span>آپلود لوگو</span>
                  </label>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Lock className="h-5 w-5" /> امنیت
                  </h3>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked={siteSettings.allowSignup} />
                    اجازه ثبت‌نام
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked={!siteSettings.maintenance} />
                    حالت تعمیرات
                  </label>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Mail className="h-5 w-5" /> ایمیل
                  </h3>
                  <input defaultValue={siteSettings.email.host} className="w-full p-2 border rounded mb-2" />
                  <input defaultValue={siteSettings.email.port} type="number" className="w-full p-2 border rounded mb-2" />
                  <input defaultValue={siteSettings.email.from} className="w-full p-2 border rounded" />
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <CreditCard className="h-5 w-5" /> پرداخت
                  </h3>
                  <input defaultValue={siteSettings.payment.stripe} className="w-full p-2 border rounded mb-2" />
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked={siteSettings.payment.paypal} />
                    PayPal
                  </label>
                </div>
              </div>
              <button className="mt-6 bg-blue-600 text-white px-6 py-2 rounded-lg">ذخیره</button>
            </div>
          )}
        </div>
      </main>

      {/* Edit Modal */}
      {isEditModalOpen && selectedContent && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg max-w-2xl w-full">
            <h3 className="font-bold mb-4">ویرایش دسترسی: {selectedContent.title}</h3>
            <div className="space-y-4">
              {["everyone", "students", "instructors", "premium"].map((key) => (
                <label key={key} className="flex items-center justify-between">
                  <span>{key === "everyone" ? "همه" : key === "students" ? "دانشجویان" : key === "instructors" ? "مدرسین" : "پریمیوم"}</span>
                  <input
                    type="checkbox"
                    checked={selectedContent.access[key as keyof typeof selectedContent.access] as boolean}
                    onChange={(e) => setSelectedContent({
                      ...selectedContent,
                      access: { ...selectedContent.access, [key]: e.target.checked }
                    })}
                    className="h-5 w-5 rounded text-blue-600"
                  />
                </label>
              ))}
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 border rounded">لغو</button>
              <button onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 bg-blue-600 text-white rounded">ذخیره</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;