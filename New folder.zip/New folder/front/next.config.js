/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
    domains: ['picsum.photos'], // اضافه کردن دامنه تصاویر خارجی
  },
}

module.exports = nextConfig
