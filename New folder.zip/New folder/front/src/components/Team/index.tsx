import { TeamType } from "@/types/team";
import SectionTitle from "../Common/SectionTitle";
import SingleTeam from "./SingleTeam";

const teamData: TeamType[] = [
  {
    id: 1,
    name: "دکتر امیرحسین رضایی",
    designation: "مؤسس و مدیرعامل",
    image: "/images/team/amirhossein-rezaei.jpg",
    facebookLink: "https://facebook.com/amirhossein.rezaei",
    twitterLink: "https://twitter.com/amirhossein_r",
    instagramLink: "https://instagram.com/amirhossein.rezaei",
  },
  {
    id: 2,
    name: "مهندس سارا کریمی",
    designation: "مدیر فنی (CTO)",
    image: "/images/team/sara-karimi.jpg",
    facebookLink: "https://facebook.com/sara.karimi",
    twitterLink: "https://twitter.com/sarakarimi_dev",
    instagramLink: "https://instagram.com/sarakarimi.dev",
  },
  {
    id: 3,
    name: "علیرضا محمدی",
    designation: "طراح تجربه کاربری",
    image: "/images/team/alireza-mohammadi.jpg",
    facebookLink: "/#",
    twitterLink: "/#",
    instagramLink: "/#",
  },
  {
    id: 4,
    name: "نرگس احمدی",
    designation: "متخصص محتوای آموزشی",
    image: "/images/team/narges-ahmadi.jpg",
    facebookLink: "/#",
    twitterLink: "/#",
    instagramLink: "/#",
  },
];

const Team = () => {
  return (
    <section
      id="team"
      className="overflow-hidden bg-gray-1 pb-12 pt-20 dark:bg-dark-2 lg:pb-[90px] lg:pt-[120px]"
    >
      <div className="container">
        <div className="mb-[60px]">
          <SectionTitle
            subtitle="تیم LXP"
            title="ما که آینده آموزش را می‌سازیم"
            paragraph="تیمی از متخصصان آموزش، فناوری و روانشناسی یادگیری — با بیش از ۱۵ سال تجربه مشترک در آموزش نوین."
            width="640px"
            center
          />
        </div>

        <div className="-mx-4 flex flex-wrap justify-center">
          {teamData.map((team) => (
            <SingleTeam key={team.id} team={team} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;