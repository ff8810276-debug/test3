import Image from "next/image";
import { Heart, MessageCircle } from "lucide-react";

// دیتای فیک (مثل پست‌های اینستاگرام)
const fakePosts = Array.from({ length: 40 }, (_, i) => {
  const randomHeight = Math.floor(Math.random() * 80) + 60; // 60 تا 140
  return {
    id: i + 1,
    image: `https://picsum.photos/seed/${i + 1}/400/300`,
    likes: Math.floor(Math.random() * 5000),
    comments: Math.floor(Math.random() * 500),
    height: `h-${randomHeight}`,
  };
});


console.log(fakePosts);


const Explore = () => {
  return (
    <section className="bg-gray-50 dark:bg-dark pb-10 pt-20 lg:pb-20 lg:pt-[120px]">
      <div className="container mx-auto px-4">
        {/* عنوان ساده و مینیمال */}
        {/* <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white md:text-4xl">
            Explore
          </h2>
        </div> */}

        {/* گرید ماسونری - شبیه اینستاگرام */}
        <div className="grid grid-cols-2 gap-1 md:grid-cols-3 lg:grid-cols-4 md:gap-2 lg:gap-3">
          {fakePosts.map((post) => (
            <div
              key={post.id}
              className={`relative group overflow-hidden rounded-lg ${post.height} w-full cursor-pointer transition-transform duration-300 hover:scale-[0.98]`}
            >
              {/* تصویر */}
              <Image
                src={post.image}
                alt={`Post ${post.id}`}
                width={400}
                height={300}
                className="object-cover w-full h-full"
              />


              {/* Overlay هنگام هاور */}
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                <div className="flex gap-6 text-white">
                  <div className="flex items-center gap-1">
                    <Heart className="w-6 h-6 fill-white" />
                    <span className="text-sm font-medium">{post.likes.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="w-6 h-6" />
                    <span className="text-sm font-medium">{post.comments}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Explore;