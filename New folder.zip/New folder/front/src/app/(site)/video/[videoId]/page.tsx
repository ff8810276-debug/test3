"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";

interface VideoItem {
  id: string;
  snippet: {
    title: string;
    channelTitle: string;
    description: string;
    publishedAt: string;
    tags?: string[];
    thumbnails: any;
  };
  statistics: {
    viewCount: string;
    likeCount: string;
    commentCount: string;
  };
  contentDetails: {
    duration: string;
  };
}

const formatNumber = (num: string) =>
  Number(num).toLocaleString("fa-IR");

const formatDate = (d: string) =>
  new Date(d).toLocaleDateString("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

const formatDuration = (iso: string) => {
  const regex = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
  const m = iso.match(regex);

  const h = Number(m?.[1] || 0);
  const min = Number(m?.[2] || 0);
  const s = Number(m?.[3] || 0);

  const pad = (n: number) => n.toString().padStart(2, "0");

  return h
    ? `${h}:${pad(min)}:${pad(s)}`
    : `${min}:${pad(s)}`;
};

export default function VideoPage() {
  const params = useParams();
  const videoId = params.videoId;

  const [video, setVideo] = useState<VideoItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showFullDesc, setShowFullDesc] = useState(false);

  useEffect(() => {
    async function fetchVideo() {
      setLoading(true);
      setError(null);

      try {
        const res = await fetch(`http://localhost:3001/youtube/videos?id=${videoId}`, {
          method: "GET",
          credentials: "include",
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.message || "خطا در دریافت ویدیو");
        }

        const data = await res.json();
        if (!data.items || data.items.length === 0) {
          setVideo(null);
        } else {
          setVideo(data.items[0]);
        }
      } catch (err: any) {
        setError(err.message || "خطای نامشخص");
      } finally {
        setLoading(false);
      }
    }

    if (videoId) fetchVideo();
  }, [videoId]);

  if (loading) return <p className="text-center mt-10">در حال بارگذاری...</p>;
  if (error) return <p className="text-center mt-10 text-red-500">{error}</p>;
  if (!video) return <p className="text-center mt-10">ویدیو پیدا نشد</p>;

  const snippet = video.snippet;
  const stats = video.statistics;
  const details = video.contentDetails;

  return (
    <section className="container mx-auto px-4 py-10">
      {/* Back */}
      <Link href="/" className="text-blue-500 underline mb-4 inline-block">
        ← بازگشت به جستجو
      </Link>

      {/* Title */}
      <h1 className="text-3xl font-bold mb-3">{snippet.title}</h1>

      {/* Channel + date */}
      <div className="text-gray-600 dark:text-gray-400 mb-4">
        {snippet.channelTitle} • {formatDate(snippet.publishedAt)}
      </div>

      {/* Stats */}
      <div className="flex gap-4 text-gray-700 dark:text-gray-300 mb-6">
        <span>👁‍🗨 {formatNumber(stats.viewCount)} بازدید</span>
        <span>👍 {formatNumber(stats.likeCount)} لایک</span>
        <span>💬 {formatNumber(stats.commentCount)} نظر</span>
        <span>⏱ {formatDuration(details.duration)}</span>
      </div>

      {/* Player */}
      <iframe
        className="w-full h-96 md:h-[500px] rounded-xl shadow mb-6"
        src={`https://www.youtube.com/embed/${video.id}`}
        allowFullScreen
      />

      {/* Tags */}
      {snippet.tags && (
        <div className="flex flex-wrap gap-2 mb-6">
          {snippet.tags.map((t) => (
            <span
              key={t}
              className="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-full text-sm"
            >
              #{t}
            </span>
          ))}
        </div>
      )}

      {/* Description */}
      <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg shadow">
        <p className="whitespace-pre-line leading-7">
          {showFullDesc
            ? snippet.description
            : snippet.description.substring(0, 300) + " ..."}
        </p>

        <button
          onClick={() => setShowFullDesc(!showFullDesc)}
          className="text-blue-500 mt-3"
        >
          {showFullDesc ? "نمایش کمتر" : "نمایش کامل توضیحات"}
        </button>
      </div>
    </section>
  );
}
