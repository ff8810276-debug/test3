declare module 'js-cookie';
