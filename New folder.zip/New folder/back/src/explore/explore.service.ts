import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExploreSetting } from './entities/explore-setting.entity';
import { Video } from '../videos/entities/video.entity';
import { YoutubeService } from '../youtube/youtube.service';

@Injectable()
export class ExploreService {
  constructor(
    @InjectRepository(ExploreSetting)
    private repo: Repository<ExploreSetting>,

    @InjectRepository(Video)
    private videoRepo: Repository<Video>,

    private youtubeService: YoutubeService,
  ) {}

  async getSettings() {
    let settings = await this.repo.findOne({ where: { id: 1 } });

    if (!settings) {
      settings = this.repo.create({});
      settings = await this.repo.save(settings);
    }

    return settings;
  }

  async updateSettings(data: Partial<ExploreSetting>) {
    const settings = await this.getSettings();
    Object.assign(settings, data);
    return this.repo.save(settings);
  }

  // --------------------------------------------------
  // 🚀 تابع اصلی گرفتن Explore
  // --------------------------------------------------
  async getExploreVideos() {
    const settings = await this.getSettings();
    const keyword = settings.keyword.toLowerCase();

    const result: any = {
      local: [],
      youtube: [],
    };

    // 1) اگر لوکال فعال است
    if (settings.allowLocal) {
      const allVideos = await this.videoRepo.find();

      const reactLocal = allVideos.filter(v =>
        (v.tags && v.tags.includes(keyword)) ||
        v.title.toLowerCase().includes(keyword)
      );

      result.local = reactLocal;
    }

    // 2) اگر یوتیوب فعال است
    if (settings.allowYoutube) {
      const youtubeResult = await this.youtubeService.searchVideos(keyword);
      result.youtube = youtubeResult.items;
    }

    return result;
  }
}
