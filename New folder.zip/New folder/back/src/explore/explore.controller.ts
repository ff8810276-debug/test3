import { Controller, Get, Put, Body } from '@nestjs/common';
import { ExploreService } from './explore.service';

@Controller('explore')
export class ExploreController {
  constructor(private exploreService: ExploreService) {}

  @Get('settings')
  getSettings() {
    return this.exploreService.getSettings();
  }

  @Put('settings')
  updateSettings(@Body() body: any) {
    return this.exploreService.updateSettings(body);
  }

  // 🚀 Route اصلی Explore
  @Get()
  getExploreVideos() {
    return this.exploreService.getExploreVideos();
  }
}
