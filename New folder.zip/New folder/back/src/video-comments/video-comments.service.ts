import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { VideoComment } from './entities/video-comment.entity';

@Injectable()
export class VideoCommentsService {
  constructor(
    @InjectRepository(VideoComment)
    private repo: Repository<VideoComment>,
  ) {}

  create(text: string, videoId: number, userId: number, parentId?: number) {
    const comment = this.repo.create({
      text,
      video: { id: videoId } as any,
      user: { id: userId } as any,
      parent: parentId ? ({ id: parentId } as any) : undefined,
    });

    return this.repo.save(comment);
  }

  getVideoComments(videoId: number) {
    return this.repo.find({
      where: { video: { id: videoId } },
      relations: ['user', 'parent'],
      order: { createdAt: 'DESC' },
    });
  }
}
