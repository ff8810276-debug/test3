import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  UploadedFiles,
  UseInterceptors,
  ParseIntPipe,
  BadRequestException,
} from '@nestjs/common';

import {
  ApiTags,
  ApiConsumes,
  ApiBody,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiNoContentResponse,
} from '@nestjs/swagger';

import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { v4 as uuid } from 'uuid';
import * as path from 'path';

import { VideosService } from './videos.service';
import { UploadMediaDto } from './dto/upload-video.dto';
import { CreateVideoDto } from './dto/create-video.dto';
import { Video } from './entities/video.entity';

@ApiTags('Videos')
@Controller('videos')
export class VideosController {
  constructor(private readonly videosService: VideosService) {}

  // GET ALL
  @Get()
  @ApiOkResponse({ type: Video, isArray: true })
  findAll() {
    return this.videosService.findAll();
  }

  // GET ONE
  @Get(':id')
  @ApiOkResponse({ type: Video })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.videosService.findOne(id);
  }

  // CREATE WITHOUT FILE (JSON)
  @Post()
  @ApiBody({ type: CreateVideoDto })
  @ApiCreatedResponse({ type: Video })
  create(@Body() dto: CreateVideoDto) {
    return this.videosService.create(dto);
  }

  // UPLOAD (POST + files)
  @Post('upload')
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: UploadMediaDto })
  @ApiCreatedResponse({ type: Video })
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'video', maxCount: 1 },
        { name: 'image', maxCount: 1 },
      ],
      {
        storage: diskStorage({
          destination: (req, file, cb) => {
            const dest =
              file.fieldname === 'video'
                ? './uploads/videos'
                : './uploads/images';
            cb(null, dest);
          },
          filename: (req, file, cb) => {
            const ext = path.extname(file.originalname);
            cb(null, `${uuid()}${ext}`);
          },
        }),
        fileFilter: (req, file, cb) => {
          if (file.fieldname === 'video' && !/\.(mp4|webm|ogg)$/i.test(file.originalname)) {
            return cb(new BadRequestException('فقط فایل ویدیویی مجاز است'), false);
          }
          if (file.fieldname === 'image' && !/\.(jpg|jpeg|png|gif)$/i.test(file.originalname)) {
            return cb(new BadRequestException('فقط تصویر مجاز است'), false);
          }
          cb(null, true);
        },
      },
    ),
  )
  async upload(
    @Body() body: UploadMediaDto,
    @UploadedFiles()
    files: { video?: Express.Multer.File[]; image?: Express.Multer.File[] },
  ) {
    const video = files.video?.[0];
    const image = files.image?.[0];

    if (!body.title?.trim()) {
      throw new BadRequestException('عنوان الزامی است');
    }

    return this.videosService.create({
      title: body.title,
      description: body.description,
      videoUrl: video ? `/uploads/videos/${video.filename}` : undefined,
      imageUrl: image ? `/uploads/images/${image.filename}` : undefined,
      tags: body.tags ? body.tags.split(',').map((t) => t.trim()) : undefined,
      duration: body.duration,
    });
  }

  // UPDATE (PUT + optional files)
  @Put(':id')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        description: { type: 'string' },
        tags: { type: 'string' },
        duration: { type: 'string' },
        video: { type: 'string', format: 'binary' },
        image: { type: 'string', format: 'binary' },
      },
    },
  })
  @ApiOkResponse({ type: Video })
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'video', maxCount: 1 },
        { name: 'image', maxCount: 1 },
      ],
      {
        storage: diskStorage({
          destination: (req, file, cb) => {
            const dest =
              file.fieldname === 'video'
                ? './uploads/videos'
                : './uploads/images';
            cb(null, dest);
          },
          filename: (req, file, cb) => {
            cb(null, `${uuid()}${path.extname(file.originalname)}`);
          },
        }),
      },
    ),
  )
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: any,
    @UploadedFiles()
    files: { video?: Express.Multer.File[]; image?: Express.Multer.File[] },
  ) {
    const videoFile = files.video?.[0];
    const imageFile = files.image?.[0];

    const updateData: Partial<CreateVideoDto> = {
      title: body.title,
      description: body.description,
      tags: body.tags ? body.tags.split(',').map((t: string) => t.trim()) : undefined,
      duration: body.duration,
    };

    if (videoFile) {
      updateData.videoUrl = `/uploads/videos/${videoFile.filename}`;
    }
    if (imageFile) {
      updateData.imageUrl = `/uploads/images/${imageFile.filename}`;
    }

    return this.videosService.update(id, updateData);
  }

  // DELETE
  @Delete(':id')
  @ApiNoContentResponse({ description: 'ویدیو حذف شد' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    await this.videosService.remove(id);
    return;
  }
}
