import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VideosService } from './videos.service';
import { VideosController } from './videos.controller';
import { Video } from './entities/video.entity';

import { VideoLikesModule } from '../video-likes/video-likes.module';
import { VideoCommentsModule } from '../video-comments/video-comments.module';
import { WatchHistoryModule } from '../watch-history/watch-history.module';
import { BookmarksModule } from '../bookmarks/bookmarks.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Video]),

    // 👇 باید حتما اینجا باشند
    VideoLikesModule,
    VideoCommentsModule,
    WatchHistoryModule,
    BookmarksModule,
  ],
  controllers: [VideosController],
  providers: [VideosService],
})
export class VideosModule {}
