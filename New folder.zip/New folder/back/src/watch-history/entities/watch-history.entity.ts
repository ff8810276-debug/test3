import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, UpdateDateColumn } from 'typeorm';
import { User } from '../../users/user.entity';
import { Video } from '../../videos/entities/video.entity';

@Entity('watch_history')
export class WatchHistory {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  @ManyToOne(() => Video, { onDelete: 'CASCADE' })
  video: Video;

  @Column({ default: 0 })
  progressSeconds: number;

  @Column({ default: false })
  completed: boolean;

  @UpdateDateColumn()
  updatedAt: Date;
}
