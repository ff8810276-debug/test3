import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { OrganizationsModule } from './organizations/organizations.module';
import { AuthModule } from './auth/auth.module';
import { YoutubeModule } from './youtube/youtube.module';
import { UserActivityModule } from './user-activity/user-activity.module';
import { VideosModule } from './videos/videos.module';
import { VideoLikesModule } from './video-likes/video-likes.module';
import { VideoCommentsModule } from './video-comments/video-comments.module';
import { WatchHistoryModule } from './watch-history/watch-history.module';
import { BookmarksModule } from './bookmarks/bookmarks.module';
import { ExploreModule } from './explore/explore.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'shortline.proxy.rlwy.net',
      port: 12723,
      username: 'postgres',
      password: 'HfKBRFSbwDDCtoFkjrVDpeMpdXZUnHTm',
      database: 'test',

      autoLoadEntities: true,   // 👈 مشکل را کاملاً حل می‌کند
      synchronize: true,
      logging: true,
    }),

    UsersModule,
    OrganizationsModule,
    AuthModule,
    YoutubeModule,
    UserActivityModule,
    VideosModule,
    VideoLikesModule,
    VideoCommentsModule,
    WatchHistoryModule,
    BookmarksModule,
    ExploreModule,

  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
