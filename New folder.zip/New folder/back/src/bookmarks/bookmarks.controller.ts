import { Controller, Post, Delete, UseGuards, Param, Req, Get } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { BookmarksService } from './bookmarks.service';

@Controller('bookmarks')
@UseGuards(AuthGuard('jwt'))
export class BookmarksController {
  constructor(private service: BookmarksService) {}

  @Post(':videoId')
  add(@Param('videoId') videoId: number, @Req() req) {
    return this.service.add(videoId, req.user.userId);
  }

  @Delete(':videoId')
  remove(@Param('videoId') videoId: number, @Req() req) {
    return this.service.remove(videoId, req.user.userId);
  }

  @Get()
  list(@Req() req) {
    return this.service.myBookmarks(req.user.userId);
  }
}
