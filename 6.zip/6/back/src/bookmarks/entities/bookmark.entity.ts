import { Entity, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, Unique } from 'typeorm';
import { User } from '../../users/user.entity';
import { Video } from '../../videos/entities/video.entity';

@Entity('video_bookmarks')
@Unique(['user', 'video'])
export class VideoBookmark {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  @ManyToOne(() => Video, { onDelete: 'CASCADE' })
  video: Video;

  @CreateDateColumn()
  createdAt: Date;
}
