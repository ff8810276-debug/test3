import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { VideoBookmark } from './entities/bookmark.entity';

@Injectable()
export class BookmarksService {
  constructor(
    @InjectRepository(VideoBookmark)
    private repo: Repository<VideoBookmark>,
  ) {}

  async add(videoId: number, userId: number) {
    const exists = await this.repo.findOne({ where: { video: { id: videoId }, user: { id: userId } } });
    if (exists) throw new ConflictException('Already bookmarked');

    const bookmark = this.repo.create({
      video: { id: videoId } as any,
      user: { id: userId } as any,
    });

    return this.repo.save(bookmark);
  }

  async remove(videoId: number, userId: number) {
    const bookmark = await this.repo.findOne({
      where: { video: { id: videoId }, user: { id: userId } },
    });

    if (!bookmark) throw new NotFoundException('Bookmark not found');

    await this.repo.remove(bookmark);
    return { message: 'Removed' };
  }

  myBookmarks(userId: number) {
    return this.repo.find({
      where: { user: { id: userId } },
      relations: ['video'],
    });
  }
}
