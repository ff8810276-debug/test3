import { Controller, Post, Body, Get, Param, UseGuards, Req } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { VideoCommentsService } from './video-comments.service';

@Controller('video-comments')
export class VideoCommentsController {
  constructor(private service: VideoCommentsService) {}

  @Get(':videoId')
  getComments(@Param('videoId') videoId: number) {
    return this.service.getVideoComments(videoId);
  }

  @UseGuards(AuthGuard('jwt'))
  @Post(':videoId')
  comment(
    @Param('videoId') videoId: number,
    @Body() body: { text: string; parentId?: number },
    @Req() req,
  ) {
    return this.service.create(body.text, videoId, req.user.userId, body.parentId);
  }
}
