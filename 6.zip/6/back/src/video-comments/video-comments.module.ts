import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VideoComment } from './entities/video-comment.entity';
import { VideoCommentsService } from './video-comments.service';
import { VideoCommentsController } from './video-comments.controller';

@Module({
  imports: [TypeOrmModule.forFeature([VideoComment])],
  controllers: [VideoCommentsController],
  providers: [VideoCommentsService],
  exports: [VideoCommentsService],
})
export class VideoCommentsModule {}
