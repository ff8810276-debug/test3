import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from '../../users/user.entity';
import { Video } from '../../videos/entities/video.entity';

@Entity('video_comments')
export class VideoComment {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  text: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  @ManyToOne(() => Video, { onDelete: 'CASCADE' })
  video: Video;

  @ManyToOne(() => VideoComment, { nullable: true })
  parent?: VideoComment;

  @CreateDateColumn()
  createdAt: Date;
}
