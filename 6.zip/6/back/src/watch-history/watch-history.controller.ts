import { Controller, Post, Body, UseGuards, Req, Get } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { WatchHistoryService } from './watch-history.service';

@Controller('watch-history')
@UseGuards(AuthGuard('jwt'))
export class WatchHistoryController {
  constructor(private service: WatchHistoryService) {}

  @Post('update')
  update(@Body() body: { videoId: number; seconds: number }, @Req() req) {
    return this.service.updateProgress(body.videoId, req.user.userId, body.seconds);
  }

  @Get()
  myHistory(@Req() req) {
    return this.service.historyForUser(req.user.userId);
  }
}
