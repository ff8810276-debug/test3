import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ILike, Repository } from 'typeorm';
import { Video } from '../videos/entities/video.entity';
import { YoutubeService } from '../youtube/youtube.service';

@Injectable()
export class SearchService {
  constructor(
    @InjectRepository(Video)
    private readonly videoRepo: Repository<Video>,
    private readonly youtubeService: YoutubeService,
  ) {}

  async searchAll(query: string) {
    const keyword = query.toLowerCase();


    // ---------------------------------
    // 🔥 FIX: Use ILike instead of Like
    // ---------------------------------
    const localVideos = await this.videoRepo.find({
      where: { title: ILike(`%${keyword}%`) },
      order: { createdAt: 'DESC' },
    });


    const youtube = await this.youtubeService.searchVideos(query);

    const result = {
      local: localVideos,
      youtube: youtube.items ?? [],
    };


    return result;
  }
}
