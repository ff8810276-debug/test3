// src/role-skills/role-skills.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RoleSkill } from './entities/role-skill.entity';
import { RoleSkillsService } from './role-skills.service';
import { Skill } from '../skills/entities/skill.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([RoleSkill, Skill]), // ← این مهم است
  ],
  providers: [RoleSkillsService],
  exports: [RoleSkillsService],
})
export class RoleSkillsModule {}
