import { Entity, PrimaryGeneratedColumn, ManyToOne, Column } from 'typeorm';
import { Skill } from '../../skills/entities/skill.entity';

@Entity('role_skills')
export class RoleSkill {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  role: string; // ADMIN, MANAGER, EMPLOYEE

  @ManyToOne(() => Skill, { eager: true, onDelete: 'CASCADE' })
  skill: Skill;
}
