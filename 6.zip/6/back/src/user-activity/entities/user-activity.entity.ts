import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
} from 'typeorm';
import { User } from '../../users/user.entity';
import { ApiProperty } from '@nestjs/swagger';

@Entity('user_activities')
export class UserActivity {
  @ApiProperty()
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty()
  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user: User;

  @ApiProperty({ example: 'VIEW_VIDEO' })
  @Column()
  action: string;

  @ApiProperty({
    example: 'LOCAL_VIDEO',
    enum: ['LOCAL_VIDEO', 'YOUTUBE_VIDEO', 'PAGE', 'COURSE'],
  })
  @Column()
  targetType: string;

  @ApiProperty({
    example: '25',
    description: 'ID ویدیو یا ID یوتیوب یا هر نوع هدف دیگر',
  })
  @Column({ nullable: true })
  targetId: string;

  @ApiProperty({
    example: { title: "React Tutorial", duration: "14:20" },
  })
  @Column({ type: 'json', nullable: true })
  meta?: any;

  @ApiProperty()
  @CreateDateColumn()
  createdAt: Date;
}
