import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { UserActivityService } from './user-activity.service';
import { UserActivity } from './entities/user-activity.entity';
import { ApiTags, ApiResponse, ApiBody } from '@nestjs/swagger';
import { CreateUserActivityDto } from './dto/create-user-activity.dto';
import { UpdateUserActivityDto } from './dto/update-user-activity.dto';

@ApiTags('User Activity')
@Controller('user-activity')
export class UserActivityController {
  constructor(private readonly activityService: UserActivityService) {}

  @Get()
  @ApiResponse({ status: 200, description: 'List of user activities', type: UserActivity, isArray: true })
  findAll(): Promise<UserActivity[]> {
    return this.activityService.findAll();
  }

  @Get(':id')
  @ApiResponse({ status: 200, description: 'Activity details', type: UserActivity })
  findOne(@Param('id') id: number): Promise<UserActivity> {
    return this.activityService.findOne(id);
  }

  @Post()
  @ApiBody({ type: CreateUserActivityDto })
  @ApiResponse({ status: 201, description: 'Activity created', type: UserActivity })
  create(@Body() dto: CreateUserActivityDto): Promise<UserActivity> {
    return this.activityService.create(dto);
  }

  @Put(':id')
  @ApiBody({ type: UpdateUserActivityDto })
  @ApiResponse({ status: 200, description: 'Activity updated', type: UserActivity })
  update(@Param('id') id: number, @Body() dto: UpdateUserActivityDto): Promise<UserActivity> {
    return this.activityService.update(id, dto);
  }

  @Delete(':id')
  @ApiResponse({ status: 204, description: 'Activity deleted' })
  remove(@Param('id') id: number): Promise<void> {
    return this.activityService.remove(id);
  }
}
