import { ApiProperty } from '@nestjs/swagger';

export class CreateUserActivityDto {
  @ApiProperty()
  userId: number;

  @ApiProperty()
  action: string;

  @ApiProperty()
  targetType: string;

  @ApiProperty({ required: false })
  targetId?: string;

  @ApiProperty({ required: false })
  title?: string;

  @ApiProperty({ required: false })
  thumbnail?: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty({
    required: false,
    description: 'Additional metadata (optional)',
    type: Object, // ⬅ اینجا اصلاح شد
  })
  meta?: Record<string, any>;
}
