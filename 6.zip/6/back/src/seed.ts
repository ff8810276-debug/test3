import { DataSource } from "typeorm";
import * as bcrypt from "bcrypt";

import { User } from "./users/user.entity";
import { Organization } from "./organizations/organization.entity";
import { Skill } from "./skills/entities/skill.entity";
import { RoleSkill } from "./role-skills/entities/role-skill.entity";
import { ExploreSetting } from "./explore/entities/explore-setting.entity";
import { Video } from "./videos/entities/video.entity";

// ==============================
//  CONNECT TO DATABASE
// ==============================
const AppDataSource = new DataSource({
  type: "postgres",
  host: "shortline.proxy.rlwy.net",
  port: 12723,
  username: "postgres",
  password: "HfKBRFSbwDDCtoFkjrVDpeMpdXZUnHTm",
  database: "test",
  entities: [User, Organization, Skill, RoleSkill, ExploreSetting, Video],
  synchronize: true,
  logging: true,
});

async function seed() {
  await AppDataSource.initialize();
  console.log("🌱 Connected to Database");

  const orgRepo = AppDataSource.getRepository(Organization);
  const userRepo = AppDataSource.getRepository(User);
  const skillRepo = AppDataSource.getRepository(Skill);
  const roleSkillRepo = AppDataSource.getRepository(RoleSkill);
  const exploreRepo = AppDataSource.getRepository(ExploreSetting);
  const videoRepo = AppDataSource.getRepository(Video);

  // ==============================
  //  CLEAR ALL TABLES
  // ==============================
  console.log("🧹 Clearing existing data...");

  await roleSkillRepo.query("DELETE FROM role_skills");
  await skillRepo.query("DELETE FROM skills");
  await userRepo.query("DELETE FROM users");
  await orgRepo.query("DELETE FROM organizations");
  await exploreRepo.query("DELETE FROM explore_settings");
  await videoRepo.query("DELETE FROM videos");

  console.log("🧹 Database cleaned.");

  // ==============================
  //  1) Organizations
  // ==============================
  const org1 = orgRepo.create({
    name: "TechCorp",
    email: "contact@techcorp.com",
    phone: "+1-202-555-0188",
    address: "123 Tech Street, NY",
  });

  const org2 = orgRepo.create({
    name: "BizSolutions",
    email: "info@bizsolutions.com",
    phone: "+1-202-555-0199",
    address: "456 Biz Avenue, CA",
  });

  await orgRepo.save([org1, org2]);
  console.log("🏢 Organizations created");

  // ==============================
  //  2) Users
  // ==============================
  const users = [
    userRepo.create({
      firstName: "John",
      lastName: "Doe",
      email: "john@example.com",
      password: await bcrypt.hash("123456", 10),
      organization: org1,
      role: "ADMIN",
    }),

    userRepo.create({
      firstName: "Jane",
      lastName: "Smith",
      email: "jane@example.com",
      password: await bcrypt.hash("123456", 10),
      organization: org2,
      role: "MANAGER",
    }),
  ];

  await userRepo.save(users);
  console.log("👤 Users created");

  // ==============================
  //  3) Skills
  // ==============================
  const skills = ["react", "javascript", "docker", "nodejs", "nestjs"].map(
    (name) => skillRepo.create({ name })
  );

  await skillRepo.save(skills);
  console.log("🧩 Skills created");

  // ==============================
  //  4) RoleSkills
  // ==============================
  const adminSkills = ["react", "nodejs", "docker"];
  const managerSkills = ["react", "javascript"];

  const roleSkillsToInsert: RoleSkill[] = [];

  adminSkills.forEach((skillName) => {
    const skill = skills.find((s) => s.name === skillName);
    if (skill) {
      roleSkillsToInsert.push(
        roleSkillRepo.create({
          role: "ADMIN",
          skill,
        })
      );
    }
  });

  managerSkills.forEach((skillName) => {
    const skill = skills.find((s) => s.name === skillName);
    if (skill) {
      roleSkillsToInsert.push(
        roleSkillRepo.create({
          role: "MANAGER",
          skill,
        })
      );
    }
  });

  await roleSkillRepo.save(roleSkillsToInsert);
  console.log("⚙️ RoleSkills created");

  // ==============================
  //  5) Explore Setting
  // ==============================
  const exploreSetting = exploreRepo.create({
    allowLocal: true,
    allowYoutube: true,
    keyword: "react",
  });

  await exploreRepo.save(exploreSetting);
  console.log("🔍 Explore settings created");

  // ==============================
  //  6) Videos
  // ==============================
  const sampleVideos = [
    videoRepo.create({
      title: "React Basics Tutorial",
      description: "Learn the basics of React in this crash course.",
      imageUrl: "/uploads/images/sample1.jpg",
      videoUrl: "/uploads/videos/sample1.mp4",
      tags: ["react", "frontend"],
      duration: "PT12M33S",
      viewCount: 1200,
    }),
    videoRepo.create({
      title: "Node.js REST API Tutorial",
      description: "Build a REST API using Node.js and Express.",
      imageUrl: "/uploads/images/sample2.jpg",
      videoUrl: "/uploads/videos/sample2.mp4",
      tags: ["nodejs", "backend"],
      duration: "PT18M20S",
      viewCount: 940,
    }),
  ];

  await videoRepo.save(sampleVideos);
  console.log("🎬 Videos seeded");

  console.log("✅ SEED COMPLETED");
  await AppDataSource.destroy();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
