// src/videos/videos.controller.ts
import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  UploadedFiles,
  UseInterceptors,
  ParseIntPipe,
  BadRequestException,
  Req,
} from '@nestjs/common';

import {
  ApiTags,
  ApiConsumes,
  ApiBody,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiNoContentResponse,
} from '@nestjs/swagger';

import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { v4 as uuid } from 'uuid';
import * as path from 'path';
import * as jwt from 'jsonwebtoken';

import { VideosService } from './videos.service';
import { UploadMediaDto } from './dto/upload-video.dto';
import { CreateVideoDto } from './dto/create-video.dto';
import { Video } from './entities/video.entity';

// ⬅⬅⬅ مهم: Request را اصلاح می‌کنیم تا cookies داشته باشد
import { Request } from 'express';

@ApiTags('Videos')
@Controller('videos')
export class VideosController {
  constructor(private readonly videosService: VideosService) {}

  @Get()
  @ApiOkResponse({ type: Video, isArray: true })
  findAll() {
    return this.videosService.findAll();
  }

  @Get(':id')
  @ApiOkResponse({ type: Video })
  async findOne(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: Request & { cookies?: any }, // ⬅⬅⬅ مشکل اینجا حل شد
  ) {
    const token = req.cookies?.accessToken;
    let userId: number | undefined = undefined;

    if (token) {
      try {
        const decoded: any = jwt.verify(
          token,
          process.env.JWT_SECRET || 'SECRET_KEY',
        );
        userId = decoded.sub;
      } catch (err) {
        console.log('❌ Invalid JWT Token for LOCAL video');
      }
    } else {
      console.log('❌ No token found for LOCAL video');
    }

    return this.videosService.findOne(id, userId);
  }

  @Post()
  @ApiBody({ type: CreateVideoDto })
  @ApiCreatedResponse({ type: Video })
  create(@Body() dto: CreateVideoDto) {
    return this.videosService.create(dto);
  }

  // UPLOAD
  @Post('upload')
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: UploadMediaDto })
  @ApiCreatedResponse({ type: Video })
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'video', maxCount: 1 },
        { name: 'image', maxCount: 1 },
      ],
      {
        storage: diskStorage({
          destination: (req, file, cb) => {
            const dest =
              file.fieldname === 'video'
                ? './uploads/videos'
                : './uploads/images';
            cb(null, dest);
          },
          filename: (req, file, cb) => {
            const ext = path.extname(file.originalname);
            cb(null, `${uuid()}${ext}`);
          },
        }),
        fileFilter: (req, file, cb) => {
          if (
            file.fieldname === 'video' &&
            !/\.(mp4|webm|ogg)$/i.test(file.originalname)
          ) {
            return cb(
              new BadRequestException('فقط فایل ویدیویی مجاز است'),
              false,
            );
          }
          if (
            file.fieldname === 'image' &&
            !/\.(jpg|jpeg|png|gif)$/i.test(file.originalname)
          ) {
            return cb(
              new BadRequestException('فقط تصویر مجاز است'),
              false,
            );
          }
          cb(null, true);
        },
      },
    ),
  )
  async upload(
    @Body() body: UploadMediaDto,
    @UploadedFiles()
    files: { video?: Express.Multer.File[]; image?: Express.Multer.File[] },
  ) {
    const video = files.video?.[0];
    const image = files.image?.[0];

    if (!body.title?.trim()) {
      throw new BadRequestException('عنوان الزامی است');
    }

    return this.videosService.create({
      title: body.title,
      description: body.description,
      videoUrl: video ? `/uploads/videos/${video.filename}` : undefined,
      imageUrl: image ? `/uploads/images/${image.filename}` : undefined,
      tags: body.tags ? body.tags.split(',').map((t) => t.trim()) : undefined,
      duration: body.duration,
    });
  }

  @Put(':id')
  @ApiConsumes('multipart/form-data')
  @ApiOkResponse({ type: Video })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: any,
  ) {
    return this.videosService.update(id, body);
  }

  @Delete(':id')
  @ApiNoContentResponse({ description: 'ویدیو حذف شد' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    await this.videosService.remove(id);
    return;
  }
}
