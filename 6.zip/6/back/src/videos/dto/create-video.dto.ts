import { ApiProperty } from '@nestjs/swagger';

export class CreateVideoDto {
  @ApiProperty()
  title: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty({ required: false })
  videoUrl?: string | null;

  @ApiProperty({ required: false })
  imageUrl?: string | null;

  @ApiProperty({
    type: [String],
    required: false,
    description: 'لیست تگ‌ها مثلا ["react","javascript"]',
  })
  tags?: string[];

  @ApiProperty({
    required: false,
    description: 'مدت ویدیو به فرمت ISO8601 مثلا PT4H43M2S',
    example: 'PT4H43M2S',
  })
  duration?: string;
}
