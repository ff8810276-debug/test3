import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VideoLike } from './entities/video-like.entity';
import { VideoLikesService } from './video-likes.service';
import { VideoLikesController } from './video-likes.controller';

@Module({
  imports: [TypeOrmModule.forFeature([VideoLike])],
  controllers: [VideoLikesController],
  providers: [VideoLikesService],
  exports: [VideoLikesService],
})
export class VideoLikesModule {}
