import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('explore_settings')
export class ExploreSetting {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ default: true })
  allowLocal: boolean;

  @Column({ default: true })
  allowYoutube: boolean;

  @Column({ default: 'react' })
  keyword: string; // فعلاً ثابت react می‌تونه باشه
}
