// src/explore/explore.service.ts

import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { ExploreSetting } from './entities/explore-setting.entity';
import { Video } from '../videos/entities/video.entity';
import { YoutubeService } from '../youtube/youtube.service';

import { User } from '../users/user.entity';
import { RoleSkill } from '../role-skills/entities/role-skill.entity';

@Injectable()
export class ExploreService {
  constructor(
    @InjectRepository(ExploreSetting)
    private repo: Repository<ExploreSetting>,

    @InjectRepository(Video)
    private videoRepo: Repository<Video>,

    @InjectRepository(User)
    private userRepo: Repository<User>,

    @InjectRepository(RoleSkill)
    private roleSkillRepo: Repository<RoleSkill>,

    private youtubeService: YoutubeService,
  ) {}

  // ----------------------------
  // تنظیمات
  // ----------------------------
  async getSettings() {
    let settings = await this.repo.findOne({ where: { id: 1 } });

    if (!settings) {
      settings = this.repo.create({});
      settings = await this.repo.save(settings);
    }

    return settings;
  }

  async updateSettings(data: Partial<ExploreSetting>) {
    const settings = await this.getSettings();
    Object.assign(settings, data);
    return this.repo.save(settings);
  }

  // ---------------------------------------------------------
  // نسخه عمومی Explore (بدون رول و بدون مهارت)
  // ---------------------------------------------------------
  async getExploreVideos() {
    const settings = await this.getSettings();
    const keyword = settings.keyword.toLowerCase();

    const result: {
      local: Video[];
      youtube: any[];
    } = {
      local: [],
      youtube: [],
    };

    // Local videos
    if (settings.allowLocal) {
      const videos = await this.videoRepo.find();
      result.local = videos.filter(
        (v) =>
          (v.tags && v.tags.includes(keyword)) ||
          v.title.toLowerCase().includes(keyword),
      );
    }

    // YouTube
    if (settings.allowYoutube) {
      const yt = await this.youtubeService.searchVideos(keyword);
      result.youtube = yt.items ?? [];
    }

    return result;
  }

  // ------------------------------------------------------------
  // 🔥 Explore مخصوص کاربر بر اساس Role و Skill های موردنیاز
  // ------------------------------------------------------------
   async getExploreVideosForUser(userId: number) {

    console.log(`\n========================`);
    console.log(`📌 [Explore] User Request`);
    console.log(`========================`);
    console.log(`➡ userId = ${userId}`);

    // 1) کاربر
    const user = await this.userRepo.findOne({
      where: { id: userId },
    });

    if (!user) throw new UnauthorizedException('User not found');

    console.log(`➡ Role = ${user.role}`);

    // 2) نقش → مهارت‌ها
    const roleSkills = await this.roleSkillRepo.find({
      where: { role: user.role },
      relations: ['skill'],
    });

    console.log(`➡ RoleSkills found = ${roleSkills.length}`);
    console.log(
      `➡ Raw RoleSkills =`,
      roleSkills.map((rs) => ({
        role: rs.role,
        skillId: rs.skill.id,
        skillName: rs.skill.name,
      }))
    );

    const skills = roleSkills.map((rs) => rs.skill.name.toLowerCase());

    console.log(`➡ Extracted Skills = ${JSON.stringify(skills)}`);

    // خروجی
    const result: {
      // skills: string[];
      local: Video[];
      youtube: any[];
    } = {
      // skills,
      local: [],
      youtube: [],
    };

    // ===============================
    // 3) Local Videos
    // ===============================
    const allVideos = await this.videoRepo.find();

    result.local = allVideos.filter((v) =>
      (v.tags || []).some((tag) =>
        skills.includes(tag.toLowerCase())
      ),
    );

    console.log(`➡ Local videos matched = ${result.local.length}`);

    // ===============================
    // 4) YouTube Videos
    // ===============================
    for (const skill of skills) {
      const yt = await this.youtubeService.searchVideos(skill);
      result.youtube.push(...(yt.items ?? []));
    }

    console.log(`➡ Youtube results = ${result.youtube.length}`);

    console.log(`========================\n`);

    return result;
  }
}
