// src/explore/explore.controller.ts

import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ExploreService } from './explore.service';
import { AuthGuard } from '@nestjs/passport';

@Controller('explore')
export class ExploreController {
  constructor(private exploreService: ExploreService) {}

  @Get('settings')
  getSettings() {
    return this.exploreService.getSettings();
  }

  // نسخه عمومی Explore
  @Get()
  getExploreVideos() {
    return this.exploreService.getExploreVideos();
  }

  // -------------------------------------------------
  // 🔥 Explore مخصوص کاربر (Role-based Personalization)
  // -------------------------------------------------
  @Get('for-user')
  @UseGuards(AuthGuard('jwt'))
  async exploreForUser(@Req() req) {
    return this.exploreService.getExploreVideosForUser(req.user.userId);
  }
}
