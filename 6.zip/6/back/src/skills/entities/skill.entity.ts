// src/skills/entities/skill.entity.ts
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('skills')
export class Skill {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string; // مثلا: react, javascript, docker
}
