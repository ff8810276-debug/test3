"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Cookies from "js-cookie";

type PostType = {
  id: string | number;
  videoId: string | number;
  isYoutube: boolean;
  image: string;
  title: string;
  channel?: string;
  views?: string;
  uploaded?: string;
  likes: number;
  comments: number;
};

const Explore = () => {
  const [posts, setPosts] = useState<PostType[]>([]);
  const token = Cookies.get("accessToken");

  useEffect(() => {
    const fetchExplore = async () => {
      const res = await fetch("http://localhost:3001/explore/for-user", {
        credentials: "include",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      console.log("data =>", data);

      // ---- یوتیوب ----
   const youtubePosts: PostType[] = data.youtube
  .filter((item: any) => item.id?.videoId) // فقط ویدیوها
  .map((item: any) => ({
    id: item.id.videoId,
    videoId: item.id.videoId,
    isYoutube: true,

    image: item.snippet.thumbnails.high.url,
    title: item.snippet.title,
    channel: item.snippet.channelTitle,
    views: Math.floor(Math.random() * 200) + "K",
    uploaded: item.snippet.publishTime,

    likes: Math.floor(Math.random() * 5000),
    comments: Math.floor(Math.random() * 300),
  }));


      // ---- لوکال ----
      const localPosts: PostType[] = data.local.map((item: any) => ({
        id: item.id,
        videoId: item.id,
        isYoutube: false,

        image: item.imageUrl || "/default-image.jpg",
        title: item.title,
        channel: "Local Content",
        views: item.viewCount + "",
        uploaded: item.createdAt,

        likes: item.likeCount,
        comments: item.commentCount,
      }));

      setPosts([...localPosts, ...youtubePosts]);
    };

    fetchExplore();
  }, []);

  console.log('posts =>' , posts)  

  return (
    <section className="pb-20 pt-24">
      <div className="container mx-auto px-4">

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {posts.map((post) => {

            // 👇 کلید یونیک 100٪
            const key = `${post.isYoutube ? "yt-" : "local-"}${post.videoId}`;

            return (
              <div key={key} className="cursor-pointer">

                <Link
                  href={
                    post.isYoutube
                      ? `/video/${post.videoId}?type=youtube`
                      : `/video/${post.videoId}?type=local`
                  }
                >
                  <div className="relative w-full aspect-video rounded-xl overflow-hidden group">

                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />

                    <div className="
                      absolute inset-0
                      bg-black bg-opacity-0
                      group-hover:bg-opacity-40
                      transition-all duration-300
                      flex items-center justify-center
                      opacity-0 group-hover:opacity-100
                    ">
                      <div className="flex gap-6 text-white">

                        {/* Likes */}
                        <div className="flex items-center gap-1">
                          <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24">
                            <path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676..." />
                          </svg>
                          <span className="text-sm font-medium">
                            {post.likes.toLocaleString()}
                          </span>
                        </div>

                        {/* Comments */}
                        <div className="flex items-center gap-1">
                          <svg className="w-6 h-6" viewBox="0 0 24 24">
                            <path d="M2.992 16.342..." />
                          </svg>
                          <span className="text-sm font-medium">
                            {post.comments}
                          </span>
                        </div>

                      </div>
                    </div>

                  </div>
                </Link>

                <div className="mt-2">
                  <h3 className="text-sm font-bold text-white line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="text-xs text-gray-400 mt-1">{post.channel}</p>

                  <p className="text-xs text-gray-500">
                    {post.views} views •{" "}
                    {post.uploaded &&
                      new Date(post.uploaded).toLocaleDateString("fa-IR")}
                  </p>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

export default Explore;
