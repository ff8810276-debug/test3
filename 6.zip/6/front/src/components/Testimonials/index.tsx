import { Testimonial } from "@/types/testimonial";
import SectionTitle from "../Common/SectionTitle";
import SingleTestimonial from "./SingleTestimonial";

const testimonialData: Testimonial[] = [
  {
    id: 1,
    name: "سارا محمدی",
    designation: "دانش‌آموز پایه دوازدهم",
    content:
      "قبل از LXP، ریاضی برام مثل کابوس بود. اما با آزمون‌های تطبیقی و توضیحات ویدیویی، تونستم تو ۳ ماه ۱۸ بگیرم! مربی هوش مصنوعی همیشه جواب می‌داد.",
    image: "/images/testimonials/student-01.jpg",
    star: 5,
  },
  {
    id: 2,
    name: "مهدی رضایی",
    designation: "پدر یک دانش‌آموز",
    content:
      "دخترم همیشه از درس خوندن فرار می‌کرد. حالا هر روز خودش می‌ره سراغ LXP. گزارش پیشرفتش رو هر هفته می‌بینم و واقعاً معجزه کرده. بهترین سرمایه‌گذاری زندگیم بود.",
    image: "/images/testimonials/parent-01.jpg",
    star: 5,
  },
  {
    id: 3,
    name: "آتنا کریمی",
    designation: "دانش‌آموز کنکوری",
    content:
      "من قبلاً ۱۰ تا کلاس تقویتی می‌رفتم. با LXP فقط ۲ ساعت در روز کافیه. پیش‌بینی نمره‌ش دقیقاً درست بود — رتبه ۹۸۲ منطقه ۱! ممنون LXP.",
    image: "/images/testimonials/student-02.jpg",
    star: 5,
  },
];

const Testimonials = () => {
  return (
    <section className="bg-gray-1 py-20 dark:bg-dark-2 md:py-[120px]">
      <div className="container px-4">
        <SectionTitle
          subtitle="نظرات کاربران"
          title="دانش‌آموزان و والدین چه می‌گویند؟"
          paragraph="بیش از ۵۰٬۰۰۰ دانش‌آموز و خانواده با LXP به موفقیت رسیده‌اند. این فقط چند نمونه از داستان‌های واقعی آنهاست."
          width="640px"
          center
        />

        <div className="mt-[60px] flex flex-wrap lg:mt-20 gap-y-8">
          {testimonialData.map((testimonial, i) => (
            <SingleTestimonial key={testimonial.id} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;